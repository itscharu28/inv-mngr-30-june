"""
AI Service — SoundMatter v2
Uses fast rule-based classification by default.
HuggingFace zero-shot is optional and only loads when explicitly requested.
"""
from typing import List, Dict, Any, Optional
import re

# ─── Rule-based classifier (default — fast, no model download) ───────────────

CATEGORY_RULES = [
    (["capacitor", "cap alum", "cap cer", "cap tant", "mlcc", "electrolytic", "farad", "uf", "pf", "nf"], "Capacitors"),
    (["resistor", "res ", " ohm", "kohm", "mohm", "thick film", "thin film", "smd res"], "Resistors"),
    (["inductor", "ferrite", "choke", "coil", "toroid", "henr"], "Inductors & Coils"),
    (["diode", "zener", "schottky", "rectifier", "tvs", "diac", "1n4148", "1n4007"], "Diodes"),
    (["transistor", "mosfet", "bjt", "igbt", "jfet", "fet "], "Transistors"),
    (["led", "light emitting", "infrared", "photodiode", "phototransistor", "opto"], "LEDs & Optoelectronics"),
    (["microcontroller", "mcu", "arduino", "esp32", "esp8266", "stm32", "avr", "pic", "atmel"], "Microcontrollers"),
    (["processor", "cpu", "fpga", "cpld", "dsp", "soc", "microprocessor"], "Processors & FPGAs"),
    (["voltage regulator", "ldo", "buck", "boost", "power management", "vreg", "dc-dc", "pmic", "switching reg"], "Power Management ICs"),
    (["op-amp", "opamp", "comparator", "amplifier", "lm741", "lm358", "ina", "opa"], "Amplifiers & Op-Amps"),
    (["logic gate", "logic ic", "74hc", "74ls", "74ac", "flip flop", "latch", "shift register", "buffer ic"], "Logic ICs"),
    (["memory", "eeprom", "flash ic", "sram", "dram", "rom", "w25q", "at24c"], "Memory ICs"),
    (["oscillator", "crystal", "resonator", "rtc", "clock gen", "xtal"], "Oscillators & Crystals"),
    (["connector", "header", "socket", "terminal", "usb conn", "plug ", "jack ", "pin connector"], "Connectors"),
    (["switch", "button", "pushbutton", "tactile", "toggle", "dip switch", "relay"], "Switches & Relays"),
    (["sensor", "accelerom", "gyro", "temperature sensor", "humidity sensor", "pressure sensor", "ultrasonic", "lidar", "imu"], "Sensors"),
    (["display", "lcd", "oled", "tft", "7-segment", "e-ink", "screen"], "Displays"),
    (["transformer", "balun", "common mode", "power transformer"], "Transformers"),
    (["fuse", "ptc", "varistor", "circuit breaker", "polyfuse"], "Protection Components"),
    (["pcb", "stencil", "solder paste", "smd board", "gerber", "bare board"], "PCBs & Manufacturing"),
    (["solder", "flux", "desoldering", "wick", "pcb cleaner"], "Soldering & Tools"),
    (["heat sink", "thermal pad", "fan", "cooling"], "Thermal Management"),
    (["antenna", "rf module", "bluetooth module", "wifi module", "nrf", "lora", "zigbee"], "Wireless & RF"),
    (["battery", "cell", "lithium", "lipo", "nimh", "charger ic"], "Power Supplies & Batteries"),
    (["motor driver", "h-bridge", "stepper driver", "servo", "encoder"], "Motor & Motion"),
    (["cable", "wire", "hookup wire", "ribbon cable", "coaxial"], "Cables & Wires"),
    (["enclosure", "box", "housing", "mount", "bracket", "standoff", "spacer", "screw", "nut"], "Mechanical & Hardware"),
    (["prototype board", "breadboard", "perfboard", "dev board"], "Development Boards"),
    (["audio", "speaker", "microphone", "codec", "dac audio", "adc audio", "amplifier board"], "Audio Components"),
]


def classify_category(text: str) -> str:
    if not text:
        return "Other Electronic Components"
    lower = text.lower()
    for keywords, category in CATEGORY_RULES:
        if any(kw in lower for kw in keywords):
            return category
    return "Other Electronic Components"


def enrich_items(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Enrich parsed items with AI category (rule-based, fast)."""
    for item in items:
        desc = item.get("description") or ""
        mfg = item.get("mfg_part_number") or ""
        text = f"{desc} {mfg}"
        item["ai_category"] = classify_category(text)
    return items


# ─── Optional HuggingFace classifier (lazy-loaded, not used by default) ──────

_classifier = None
_classifier_loaded = False


def get_classifier():
    """Load HuggingFace zero-shot classifier (only called if explicitly requested)."""
    global _classifier, _classifier_loaded
    if _classifier_loaded:
        return _classifier
    try:
        from transformers import pipeline
        _classifier = pipeline(
            "zero-shot-classification",
            model="facebook/bart-large-mnli",
            device=-1  # CPU
        )
        print("[AI] HuggingFace classifier loaded successfully")
    except Exception as e:
        print(f"[AI] HuggingFace classifier unavailable — using rule-based: {e}")
        _classifier = None
    _classifier_loaded = True
    return _classifier


def classify_with_hf(text: str, categories: Optional[List[str]] = None) -> str:
    """Classify using HuggingFace if available, fallback to rule-based."""
    clf = get_classifier()
    if clf is None:
        return classify_category(text)

    if not categories:
        categories = [cat for _, cat in CATEGORY_RULES] + ["Other Electronic Components"]

    try:
        result = clf(text, candidate_labels=categories)
        return result["labels"][0]
    except Exception:
        return classify_category(text)


# ─── Stock Query (rule-based NL answering) ────────────────────────────────────

def answer_stock_query(question: str, stock_data: list) -> str:
    """
    Answer natural language questions about stock using rule-based logic.
    No external model needed.
    """
    if not stock_data:
        return "No stock data available. Please import invoices first."

    q = question.lower()

    # Low stock questions
    if any(w in q for w in ["low", "running out", "reorder", "less than", "shortage"]):
        low = [s for s in stock_data if 0 < (s.get("quantity") or 0) < 10]
        if not low:
            return "No items are currently low on stock."
        names = ", ".join(f"{s['product_name']} ({s['quantity']} left)" for s in low[:10])
        return f"⚠️ {len(low)} item(s) are low on stock: {names}"

    # Out of stock questions
    if any(w in q for w in ["out of stock", "zero", "empty", "no stock", "unavailable"]):
        out = [s for s in stock_data if (s.get("quantity") or 0) == 0]
        if not out:
            return "No items are currently out of stock."
        names = ", ".join(s["product_name"] for s in out[:10])
        return f"🚫 {len(out)} item(s) are out of stock: {names}"

    # Total value
    if any(w in q for w in ["value", "worth", "total cost", "inventory cost"]):
        total = sum(
            (s.get("quantity") or 0) * (s.get("unit_price") or 0)
            for s in stock_data
        )
        return f"💰 Total inventory value is ${total:,.2f} USD across {len(stock_data)} product(s)."

    # Most stock / highest quantity
    if any(w in q for w in ["most", "highest quantity", "maximum", "top stock"]):
        top = sorted(stock_data, key=lambda s: s.get("quantity") or 0, reverse=True)[:5]
        lines = [f"{s['product_name']}: {s['quantity']} units" for s in top]
        return "📦 Products with most stock:\n" + "\n".join(lines)

    # Least stock
    if any(w in q for w in ["least", "lowest quantity", "minimum"]):
        bottom = sorted(
            [s for s in stock_data if (s.get("quantity") or 0) > 0],
            key=lambda s: s.get("quantity") or 0
        )[:5]
        lines = [f"{s['product_name']}: {s['quantity']} units" for s in bottom]
        return "📉 Products with least stock:\n" + "\n".join(lines)

    # Category breakdown
    if any(w in q for w in ["category", "categories", "type", "breakdown"]):
        from collections import defaultdict
        cats = defaultdict(int)
        for s in stock_data:
            cat = s.get("category") or "Uncategorized"
            cats[cat] += s.get("quantity") or 0
        sorted_cats = sorted(cats.items(), key=lambda x: x[1], reverse=True)
        lines = [f"{cat}: {qty} units" for cat, qty in sorted_cats[:10]]
        return "📊 Stock by category:\n" + "\n".join(lines)

    # Count / how many
    if any(w in q for w in ["how many", "count", "total products", "how much"]):
        total_items = len(stock_data)
        total_units = sum(s.get("quantity") or 0 for s in stock_data)
        return f"📦 {total_items} unique product(s) in stock with {total_units} total units."

    # Search by name
    words = [w for w in q.split() if len(w) > 3]
    matches = [
        s for s in stock_data
        if any(w in (s.get("product_name") or "").lower() for w in words)
        or any(w in (s.get("category") or "").lower() for w in words)
    ]
    if matches:
        lines = [f"{s['product_name']}: {s['quantity']} units @ ${s.get('unit_price') or 0:.4f}" for s in matches[:10]]
        return f"🔍 Found {len(matches)} matching product(s):\n" + "\n".join(lines)

    # Default summary
    total_units = sum(s.get("quantity") or 0 for s in stock_data)
    total_value = sum((s.get("quantity") or 0) * (s.get("unit_price") or 0) for s in stock_data)
    low_count = len([s for s in stock_data if 0 < (s.get("quantity") or 0) < 10])
    return (
        f"📦 Inventory Summary: {len(stock_data)} products, "
        f"{total_units} total units, "
        f"${total_value:,.2f} total value"
        + (f", ⚠️ {low_count} low-stock item(s)" if low_count else "")
    )
