"""
PDF Parser Service — SoundMatter v2
Supports: Mouser Electronics, DigiKey, JLCPCB invoice formats
+ Image/scanned PDF via OCR (pytesseract)
"""
import re
import io
from typing import List, Dict, Any

try:
    import pdfplumber
    HAS_PDFPLUMBER = True
except ImportError:
    HAS_PDFPLUMBER = False

try:
    import fitz
    HAS_FITZ = True
except ImportError:
    HAS_FITZ = False

try:
    import pytesseract
    from PIL import Image
    HAS_OCR = True
except ImportError:
    HAS_OCR = False


# ─── Main entry point ────────────────────────────────────────────────────────

def parse_mouser_pdf(file_bytes: bytes) -> List[Dict[str, Any]]:
    """
    Auto-detect invoice format and parse accordingly.
    Supports: Mouser, DigiKey, JLCPCB, and image/scanned PDFs.
    """
    if HAS_PDFPLUMBER:
        _, full_text = _extract_text_pdfplumber(file_bytes)
        if full_text.strip():
            items = _detect_and_parse(full_text)
            if items:
                return _deduplicate(items)

    if HAS_FITZ and HAS_OCR:
        items = _parse_with_ocr(file_bytes)
        if items:
            return _deduplicate(items)

    if HAS_FITZ:
        _, full_text = _extract_text_fitz(file_bytes)
        if full_text.strip():
            items = _detect_and_parse(full_text)
            if items:
                return _deduplicate(items)

    return []


# ─── Format detection ────────────────────────────────────────────────────────

def _detect_and_parse(text: str) -> List[Dict[str, Any]]:
    """Detect invoice format and route to correct parser."""
    upper = text.upper()

    # DigiKey: has "PART:" and "DESC:" and "HTSUS:" or "DIGIKEY"
    if "PART:" in upper and "DESC:" in upper and ("HTSUS:" in upper or "DIGIKEY" in upper):
        items = _parse_digikey(text)
        if items:
            return items

    # JLCPCB: has "JLCPCB" or "Grand Total" with "USD" format
    if "JLCPCB" in upper or ("GRAND TOTAL" in upper and "USD" in upper):
        items = _parse_jlcpcb(text)
        if items:
            return items

    # Mouser: has "MFG Part No:" or Mouser part pattern (XX-XXXXX)
    items = _parse_mouser(text)
    if items:
        return items

    return []


# ─── Mouser Parser ────────────────────────────────────────────────────────────

def _parse_mouser(text: str) -> List[Dict[str, Any]]:
    """Parse Mouser Electronics invoice format."""
    items = []
    lines = text.split("\n")

    line_item_pattern = re.compile(
        r"^\s*\d+\s+"
        r"(\d{2,3}-[A-Z0-9\-]{3,})"
        r"\s+(\d{1,6})\s+(\d{1,6})\s+(\d{1,6})"
        r"\s+([\d,]+\.?\d*)\s+([\d,]+\.?\d*)"
    )
    mfg_pattern = re.compile(r"(?i)MFG\s*Part\s*No[.:]?\s*(.+)")
    hts_pattern = re.compile(r"(?i)(?:US\s*)?HTS[:\s]*(\d[\d\.]+)")

    invoice_summary = _extract_mouser_summary(text)
    current = None
    desc_lines = []

    skip_desc = [
        "US HTS", "ECCN", "COO:", "INCOTERMS", "MOUSER PART",
        "LINE NO", "QUANTITY", "UNIT PRICE", "EXTENDED",
        "MERCHANDISE", "HANDLING", "FREIGHT", "SHIPPING INFORMATION",
        "TRACKING NUMBER", "PAID BY", "BILL TO", "SHIP TO",
        "INVOICE", "PURCHASE ORDER", "SHIP DATE", "SHIP VIA",
        "CUSTOMER NUMBER", "TERMS", "ORDER DATE", "MASTER TRACKER",
        "CONTACT NAME", "CREDIT:", "FEDERAL ID", "CUSTOMER SERVICE",
        "1000 NORTH MAIN",
    ]

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        lm = line_item_pattern.match(stripped)
        if lm:
            if current and current.get("mouser_part_number"):
                if desc_lines:
                    current["description"] = _clean_description(" ".join(desc_lines))
                    desc_lines = []
                items.append(current)
            current = _empty_item()
            current["mouser_part_number"] = lm.group(1)
            current["qty_ordered"] = _safe_int(lm.group(2))
            current["qty_shipped"] = _safe_int(lm.group(3))
            current["qty_pending"] = _safe_int(lm.group(4))
            current["unit_price"] = _safe_float(lm.group(5))
            current["extended_price"] = _safe_float(lm.group(6))
            current["source_vendor"] = "Mouser"
            continue

        mfg_m = mfg_pattern.match(stripped)
        if mfg_m and current:
            current["mfg_part_number"] = mfg_m.group(1).strip()
            continue

        hts_m = hts_pattern.search(stripped)
        if hts_m and current:
            current["tariff"] = hts_m.group(1).strip()
            continue

        if current:
            if not any(x in stripped.upper() for x in skip_desc):
                if len(stripped) > 3 and not re.match(r"^\d[\d\s\.]+$", stripped):
                    desc_lines.append(stripped)

    if current and current.get("mouser_part_number"):
        if desc_lines:
            current["description"] = _clean_description(" ".join(desc_lines))
        items.append(current)

    if items and invoice_summary:
        items[0]["invoice_summary"] = invoice_summary

    if not items:
        items = _parse_mouser_legacy(text)

    return items


def _extract_mouser_summary(text: str) -> Dict[str, Any]:
    summary = {
        "merchandise": None, "handling": None,
        "freight": None, "tax": None, "tariff": None,
        "invoice_total": None, "invoice_number": None, "invoice_date": None,
        "vendor": "Mouser"
    }
    inv_m = re.search(r"Invoice\s*No[.:]?\s*(\d+)", text, re.IGNORECASE)
    if inv_m:
        summary["invoice_number"] = inv_m.group(1)
    else:
        inv_m2 = re.search(r"Invoice\s*No\..*?\n.*?(\d{7,})", text, re.IGNORECASE | re.DOTALL)
        if inv_m2:
            summary["invoice_number"] = inv_m2.group(1)
        else:
            inv_m3 = re.search(r"(\d{7,9})\s+\d{2}-\w{3}-\d{2}", text)
            if inv_m3:
                summary["invoice_number"] = inv_m3.group(1)
    date_m = re.search(r"Invoice\s*Date[:\s]+(\d{2}-\w{3}-\d{2,4})", text, re.IGNORECASE)
    if date_m:
        summary["invoice_date"] = date_m.group(1)
    merch_idx = text.lower().find("merchandise")
    if merch_idx >= 0:
        after = text[merch_idx:]
        sm = re.search(r"([\d,]+\.?\d*)\s+([\d,]+\.?\d*)\s+([\d,]+\.?\d*)\s+([\d,]+\.?\d*)\s+([\d,]+\.?\d*)", after[:300])
        if sm:
            summary["merchandise"] = _safe_float(sm.group(1))
            summary["handling"] = _safe_float(sm.group(2))
            summary["freight"] = _safe_float(sm.group(3))
            summary["tax"] = _safe_float(sm.group(4))
            summary["tariff"] = _safe_float(sm.group(5))
    paid_m = re.search(r"Paid\s+by\s+credit\s+card\s+USD\s*\$?([\d,]+\.?\d*)", text, re.IGNORECASE)
    if paid_m:
        summary["invoice_total"] = _safe_float(paid_m.group(1))
    return summary


def _parse_mouser_legacy(text: str) -> List[Dict[str, Any]]:
    """Fallback Mouser parser for older/different layouts."""
    items = []
    lines = text.split("\n")
    mfg_pattern = re.compile(r"(?i)MFG\s*Part\s*No[.:]?\s*(.+)")
    numbers_pattern = re.compile(r"(\d{1,6})\s+(\d{1,6})\s+(\d{1,6})\s+([\d,]+\.?\d*)\s+([\d,]+\.?\d*)")
    hts_pattern = re.compile(r"(?i)(?:US\s*)?HTS[:\s]+(\d[\d\.]+)")
    current = None
    desc_lines = []
    collecting_desc = False

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        mfg_m = mfg_pattern.match(stripped)
        if mfg_m:
            if current and current.get("mfg_part_number"):
                if desc_lines:
                    current["description"] = _clean_description(" ".join(desc_lines))
                    desc_lines = []
                if current.get("qty_ordered") or current.get("unit_price"):
                    items.append(current)
                    current = None
            if current is None:
                current = _empty_item()
            current["mfg_part_number"] = mfg_m.group(1).strip()
            current["source_vendor"] = "Mouser"
            collecting_desc = True
            continue
        hts_m = hts_pattern.search(stripped)
        if hts_m and current:
            current["tariff"] = hts_m.group(1).strip()
            continue
        if collecting_desc and current:
            num_m = numbers_pattern.search(stripped)
            if num_m:
                if desc_lines:
                    current["description"] = _clean_description(" ".join(desc_lines))
                    desc_lines = []
                current["qty_ordered"] = _safe_int(num_m.group(1))
                current["qty_shipped"] = _safe_int(num_m.group(2))
                current["qty_pending"] = _safe_int(num_m.group(3))
                current["unit_price"] = _safe_float(num_m.group(4))
                current["extended_price"] = _safe_float(num_m.group(5))
                if current.get("mfg_part_number"):
                    items.append(current)
                current = None
                collecting_desc = False
                continue
            skip = ["US HTS", "ECCN", "COO:", "COUNTRY OF ORIGIN"]
            if any(x in stripped.upper() for x in skip):
                continue
            if stripped and len(stripped) > 2:
                desc_lines.append(stripped)
        mouser_m = re.search(r"\b(\d{2,3}-[A-Z0-9\-]{5,})\b", stripped)
        if mouser_m:
            if current is None:
                current = _empty_item()
            current["mouser_part_number"] = mouser_m.group(1)
    if current and current.get("mfg_part_number"):
        if desc_lines:
            current["description"] = _clean_description(" ".join(desc_lines))
        items.append(current)
    return items


# ─── DigiKey Parser ───────────────────────────────────────────────────────────

def _parse_digikey(text: str) -> List[Dict[str, Any]]:
    """
    Parse DigiKey invoice format.
    Format 1 (combined): '1 50 0 50 PART: 493-9827-1-ND DESC: CAP ALUM 10UF 0.39220 19.61 T'
    Format 2 (split):    '1 50 0 50 PART: 493-9827-1-ND'
                         'DESC: CAP ALUM 10UF 20% 50V SMD 0.39220 19.61'
    MFG line:  'MFG : Nichicon (VA) / UWP1H100MCL1GB'
    HTS line:  '...HTSUS: 8532.22.0020'
    """
    items = []
    lines = text.split("\n")

    dk_combined = re.compile(
        r"^\s*(\d+)\s+(\d+)\s+\d+\s+(\d+)\s+"
        r"PART:\s+([A-Z0-9\-]+)\s+"
        r"DESC:\s+(.+?)\s+([\d.]+)\s+([\d.]+)\s*T?\s*$",
        re.IGNORECASE
    )
    dk_line = re.compile(
        r"^\s*(\d+)\s+(\d+)\s+\d+\s+(\d+)\s+PART:\s+([A-Z0-9\-]+)\s*$",
        re.IGNORECASE
    )
    dk_desc = re.compile(r"DESC:\s*(.+?)\s+([\d.]+)\s+([\d.]+)\s*T?\s*$", re.IGNORECASE)
    dk_mfg = re.compile(r"MFG\s*:\s*[^/]+/\s*(.+)", re.IGNORECASE)
    dk_hts = re.compile(r"HTSUS:\s*([\d.]+)", re.IGNORECASE)

    invoice_summary = _extract_digikey_summary(text)
    current = None

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue

        cm = dk_combined.match(stripped)
        if cm:
            if current and current.get("mouser_part_number"):
                items.append(current)
            current = _empty_item()
            current["mouser_part_number"] = cm.group(4).strip()
            current["qty_ordered"] = _safe_int(cm.group(2))
            current["qty_shipped"] = _safe_int(cm.group(3))
            current["qty_pending"] = max(0, _safe_int(cm.group(2)) - _safe_int(cm.group(3)))
            current["description"] = cm.group(5).strip()
            current["unit_price"] = _safe_float(cm.group(6))
            current["extended_price"] = _safe_float(cm.group(7))
            current["source_vendor"] = "DigiKey"
            continue

        lm = dk_line.match(stripped)
        if lm:
            if current and current.get("mouser_part_number"):
                items.append(current)
            current = _empty_item()
            current["mouser_part_number"] = lm.group(4).strip()
            current["qty_ordered"] = _safe_int(lm.group(2))
            current["qty_shipped"] = _safe_int(lm.group(3))
            current["qty_pending"] = max(0, _safe_int(lm.group(2)) - _safe_int(lm.group(3)))
            current["source_vendor"] = "DigiKey"
            continue

        desc_m = dk_desc.match(stripped)
        if desc_m and current and not current.get("description"):
            current["description"] = desc_m.group(1).strip()
            current["unit_price"] = _safe_float(desc_m.group(2))
            current["extended_price"] = _safe_float(desc_m.group(3))
            continue

        mfg_m = dk_mfg.match(stripped)
        if mfg_m and current:
            mfg_clean = re.sub(r'\s*\(VA\)\s*', '', mfg_m.group(1)).strip()
            current["mfg_part_number"] = mfg_clean
            continue

        hts_m = dk_hts.search(stripped)
        if hts_m and current:
            current["tariff"] = hts_m.group(1).strip()
            continue

    if current and current.get("mouser_part_number"):
        items.append(current)

    if items and invoice_summary:
        items[0]["invoice_summary"] = invoice_summary

    return items


def _extract_digikey_summary(text: str) -> Dict[str, Any]:
    summary = {
        "merchandise": None, "handling": None,
        "freight": None, "tax": None, "tariff": None,
        "invoice_total": None, "invoice_number": None, "invoice_date": None,
        "vendor": "DigiKey"
    }
    inv_m = re.search(r"Invoice\s*#\s*(\d+)", text, re.IGNORECASE)
    if inv_m:
        summary["invoice_number"] = inv_m.group(1)
    date_m = re.search(r"Invoice\s*Date[:\s]+(\d{2}-\w{3}-\d{4})", text, re.IGNORECASE)
    if date_m:
        summary["invoice_date"] = date_m.group(1)
    merch_m = re.search(r"Sales\s*Amount\s+([\d.]+)", text, re.IGNORECASE)
    if merch_m:
        summary["merchandise"] = _safe_float(merch_m.group(1))
    ship_m = re.search(r"Shipping\s*charges\s*applied\s+([\d.]+)", text, re.IGNORECASE)
    if ship_m:
        summary["freight"] = _safe_float(ship_m.group(1))
    tax_m = re.search(r"Sales\s*Tax\s+([\d.]+)", text, re.IGNORECASE)
    if tax_m:
        summary["tax"] = _safe_float(tax_m.group(1))
    total_m = re.search(r"Total\s+charged\s+to\s+credit\s+card\s+([\d.]+)", text, re.IGNORECASE)
    if total_m:
        summary["invoice_total"] = _safe_float(total_m.group(1))
    return summary


# ─── JLCPCB Parser ───────────────────────────────────────────────────────────

def _parse_jlcpcb(text: str) -> List[Dict[str, Any]]:
    """
    Parse JLCPCB invoice format.
    Line: '1 Solder Paste Stencil  SMTBDxM  SO12601256383  1  USD 3.00  USD 3.00'
    """
    items = []
    lines = text.split("\n")

    jlc_pattern = re.compile(
        r"^(\d+)\s+(.+?)\s+(\d+)\s+USD\s*\$?([\d.]+)\s+USD\s*\$?([\d.]+)",
        re.IGNORECASE
    )

    invoice_summary = _extract_jlcpcb_summary(text)

    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        m = jlc_pattern.match(stripped)
        if m:
            desc = m.group(2).strip()
            # Clean file names / order numbers from description
            desc = re.sub(r'\s+[A-Z][0-9]{10,}\s*', ' ', desc).strip()
            desc = re.sub(r'\s+[A-Z0-9]{10,}\s*', ' ', desc).strip()
            desc = re.sub(r'\s+\d+\s*$', '', desc).strip()

            line_num = m.group(1)
            qty = _safe_int(m.group(3))

            item = _empty_item()
            item["description"] = desc[:100]
            item["qty_ordered"] = qty
            item["qty_shipped"] = qty
            item["qty_pending"] = 0
            item["unit_price"] = _safe_float(m.group(4))
            item["extended_price"] = _safe_float(m.group(5))
            item["source_vendor"] = "JLCPCB"
            # Use line number + description snippet as unique identifier for dedup
            item["mouser_part_number"] = f"JLCPCB-L{line_num}"
            item["mfg_part_number"] = None
            items.append(item)

    if items and invoice_summary:
        items[0]["invoice_summary"] = invoice_summary

    return items


def _extract_jlcpcb_summary(text: str) -> Dict[str, Any]:
    summary = {
        "merchandise": None, "handling": None,
        "freight": None, "tax": None, "tariff": None,
        "invoice_total": None, "invoice_number": None, "invoice_date": None,
        "vendor": "JLCPCB"
    }
    inv_m = re.search(r"Invoice\s*No[.:]?\s*([A-Z0-9]+)", text, re.IGNORECASE)
    if inv_m:
        summary["invoice_number"] = inv_m.group(1)
    date_m = re.search(r"Invoice\s*Date[:\s]+(\d{2}/\d{2}/\d{4}|\d{4}-\d{2}-\d{2}|\d{2}-\w{3}-\d{4})", text, re.IGNORECASE)
    if date_m:
        summary["invoice_date"] = date_m.group(1)
    merch_m = re.search(r"Merchandise\s*Total[:\s]+USD\s*\$?([\d.]+)", text, re.IGNORECASE)
    if merch_m:
        summary["merchandise"] = _safe_float(merch_m.group(1))
    ship_m = re.search(r"Shipping[:\s]+USD\s*\$?([\d.]+)", text, re.IGNORECASE)
    if ship_m:
        summary["freight"] = _safe_float(ship_m.group(1))
    tax_m = re.search(r"Sales.*?Tax[:\s]+USD\s*\$?([\d.]+)", text, re.IGNORECASE)
    if tax_m:
        summary["tax"] = _safe_float(tax_m.group(1))
    import_m = re.search(r"Import\s*Tax[:\s]+USD\s*\$?([\d.]+)", text, re.IGNORECASE)
    if import_m:
        summary["tariff"] = _safe_float(import_m.group(1))
    grand_m = re.search(r"Grand\s*Total[:\s]+USD\s*\$?([\d.]+)", text, re.IGNORECASE)
    if grand_m:
        summary["invoice_total"] = _safe_float(grand_m.group(1))
    return summary


# ─── OCR parser ──────────────────────────────────────────────────────────────

def _parse_with_ocr(file_bytes: bytes) -> List[Dict[str, Any]]:
    if not HAS_FITZ or not HAS_OCR:
        return []
    doc = fitz.open(stream=file_bytes, filetype="pdf")
    all_text_parts = []
    seen_pages = set()
    for page_num in range(len(doc)):
        page = doc[page_num]
        mat = fitz.Matrix(150 / 72, 150 / 72)
        pix = page.get_pixmap(matrix=mat, colorspace=fitz.csGRAY)
        img = Image.frombytes("L", [pix.width, pix.height], pix.samples)
        img = img.point(lambda x: 0 if x < 140 else 255, '1')
        text = pytesseract.image_to_string(img, config="--psm 6 --oem 3")
        fingerprint = text.strip()[:200]
        if fingerprint and fingerprint not in seen_pages:
            seen_pages.add(fingerprint)
            all_text_parts.append(text)
    doc.close()
    if not all_text_parts:
        return []
    full_text = _fix_ocr_text("\n".join(all_text_parts))
    return _detect_and_parse(full_text)


def _fix_ocr_text(text: str) -> str:
    text = re.sub(r"([A-Z]{2,})O(?=[0-9])", lambda m: m.group(1) + "0", text)
    text = re.sub(r"([0-9])O(?=[A-Z0-9])", lambda m: m.group(1) + "0", text)
    text = re.sub(r"(?i)MFG\s*Part\s*N[o0O][.:]?", "MFG Part No:", text)
    text = re.sub(r"(\d)\s{2,}(\d)", r"\1 \2", text)
    return text


# ─── Text extractors ─────────────────────────────────────────────────────────

def _extract_text_pdfplumber(file_bytes: bytes):
    full_text = ""
    with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
        pages_text = []
        for page in pdf.pages:
            text = page.extract_text() or ""
            pages_text.append(text)
        unique = _deduplicate_pages(pages_text)
        full_text = "\n".join(unique)
    return [], full_text


def _extract_text_fitz(file_bytes: bytes):
    if not HAS_FITZ:
        return [], ""
    doc = fitz.open(stream=file_bytes, filetype="pdf")
    seen = set()
    parts = []
    for page in doc:
        text = page.get_text()
        fp = text.strip()[:200]
        if fp and fp not in seen:
            seen.add(fp)
            parts.append(text)
    doc.close()
    return [], "\n".join(parts)


def _deduplicate_pages(pages: List[str]) -> List[str]:
    seen = set()
    unique = []
    for page in pages:
        fp = page.strip()[:200]
        if fp and fp not in seen:
            seen.add(fp)
            unique.append(page)
    return unique


# ─── Helpers ─────────────────────────────────────────────────────────────────

_DESC_NOISE = [
    "Ship Date", "Tracking Number", "This order is subject",
    "https://", "Paid by credit card", "0864", "1Z", "ROHS",
    "NON CANCELLABLE", "CERTIFICATE OF", "DigiKey requires",
    "All errors", "All transactions"
]

def _clean_description(desc: str) -> str:
    if not desc:
        return desc
    for stop in _DESC_NOISE:
        idx = desc.find(stop)
        if idx > 0:
            desc = desc[:idx].strip()
    return " ".join(desc.split())[:150].strip()


def _empty_item() -> Dict[str, Any]:
    return {
        "mouser_part_number": None,
        "mfg_part_number": None,
        "description": None,
        "qty_ordered": 0,
        "qty_shipped": 0,
        "qty_pending": 0,
        "unit_price": 0.0,
        "extended_price": 0.0,
        "tariff": None,
        "matched": False,
        "product_id": None,
        "product_name": None,
        "invoice_summary": None,
        "source_vendor": None,
    }


def _deduplicate(items: List[Dict]) -> List[Dict]:
    seen = set()
    result = []
    for item in items:
        # Use mouser_part_number OR mfg_part_number OR description+vendor as key
        part_key = item.get("mfg_part_number") or item.get("mouser_part_number")
        if part_key:
            key = (part_key, item.get("source_vendor"))
        else:
            # For items with no part number (e.g. JLCPCB), use description + vendor
            key = (item.get("source_vendor"), (item.get("description") or "")[:50])
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def _safe_int(s) -> int:
    try:
        return int(str(s).replace(",", "").strip())
    except Exception:
        return 0


def _safe_float(s) -> float:
    try:
        return float(str(s).replace(",", "").strip())
    except Exception:
        return 0.0
