from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from config.settings import settings
from routers import auth_router, pdf_router, stock_router, products_router, ai_router, bom_router
import threading


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: pre-load AI classifier in background (optional, rule-based is default)
    threading.Thread(target=_preload_classifier, daemon=True).start()
    yield
    # Shutdown: nothing needed


def _preload_classifier():
    try:
        from services.ai_service import get_classifier
        get_classifier()
    except Exception as e:
        print(f"[AI] Classifier preload skipped: {e}")


app = FastAPI(
    title="SM-InventoryManagementSystem API",
    description="AI-powered Inventory Management — FastAPI + Supabase",
    version="2.0.0",
    lifespan=lifespan,
)

origins = [o.strip() for o in settings.CORS_ORIGINS.split(",")]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router.router)
app.include_router(pdf_router.router)
app.include_router(stock_router.router)
app.include_router(products_router.router)
app.include_router(ai_router.router)
app.include_router(bom_router.router)


@app.get("/")
def root():
    return {"app": "SM-InventoryManagementSystem", "version": "2.0.0", "status": "running", "docs": "/docs"}


@app.get("/health")
def health():
    return {"status": "ok"}
