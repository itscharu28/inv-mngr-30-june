from supabase import create_client, Client
from config.settings import settings
import threading

_client: Client = None
_lock = threading.Lock()

def get_supabase() -> Client:
    global _client
    with _lock:
        if _client is None:
            _client = create_client(
                settings.SUPABASE_URL,
                settings.SUPABASE_SERVICE_KEY
            )
    return _client

def reset_client():
    global _client
    with _lock:
        _client = None