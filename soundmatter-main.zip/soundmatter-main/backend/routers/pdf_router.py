from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from typing import List, Dict, Any
from auth.jwt_handler import get_current_user
from services.pdf_parser import parse_mouser_pdf
from services.ai_service import enrich_items
from db.supabase_client import get_supabase
import re

router = APIRouter(prefix="/pdf", tags=["PDF Scanner"])


@router.post("/parse")
async def parse_pdf(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    # Accept pdf and octet-stream (some browsers send octet-stream)
    if file.content_type not in ("application/pdf", "application/octet-stream", "binary/octet-stream"):
        raise HTTPException(status_code=400, detail="Only PDF files accepted")

    content = await file.read()
    if len(content) > 20 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="File too large (max 20MB)")
    if len(content) < 100:
        raise HTTPException(status_code=400, detail="File appears to be empty or corrupt")

    try:
        items = parse_mouser_pdf(content)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF parsing failed: {str(e)}")

    if not items:
        return {
            "success": False,
            "message": "PDF parsed but no line items found. Ensure this is a Mouser, DigiKey, or JLCPCB invoice.",
            "items": [],
            "total": 0
        }

    enriched = enrich_items(items)
    matched = await _match_products(enriched, current_user)

    return {
        "success": True,
        "message": f"{len(matched)} item(s) extracted from PDF",
        "items": matched,
        "total": len(matched)
    }


@router.post("/add-to-stock")
async def add_to_stock(
    payload: Dict[str, Any],
    current_user: dict = Depends(get_current_user)
):
    items: List[Dict] = payload.get("items", [])
    source_invoice = payload.get("source_invoice", "IMPORT")

    if not items:
        raise HTTPException(status_code=400, detail="No items provided")

    sb = get_supabase()
    added = 0
    created = 0
    skipped = 0
    errors = []
    total_spend = 0.0

    for item in items:
        try:
            qty = int(item.get("qty_shipped") or item.get("qty_ordered") or 1)
            unit_price = float(item.get("unit_price") or 0.0)
            tariff = item.get("tariff") or None
            mfg_part = (item.get("mfg_part_number") or "").strip()
            mouser_part = (item.get("mouser_part_number") or "").strip()
            description = (item.get("description") or "").strip()
            ai_category = item.get("ai_category") or "Other Electronic Components"
            extended = float(item.get("extended_price") or (qty * unit_price))
            total_spend += extended
            source_vendor = item.get("source_vendor") or "Unknown"

            product_id = item.get("product_id")

            if not product_id:
                code = _make_code(mfg_part or mouser_part or description)
                existing_code = sb.table("products").select("id").eq("code", code).execute()
                if existing_code.data:
                    product_id = existing_code.data[0]["id"]
                else:
                    name = _make_name(description, mfg_part, mouser_part)
                    new_prod = sb.table("products").insert({
                        "name": name,
                        "code": code,
                        "barcode": mfg_part.upper() if mfg_part else None,
                        "category": ai_category,
                        "unit_price": unit_price,
                        "description": description[:200] if description else None,
                        "created_by": current_user.get("sub"),
                    }).execute()

                    if not new_prod.data:
                        skipped += 1
                        errors.append(f"Failed to create product for {mfg_part or mouser_part}")
                        continue

                    product_id = new_prod.data[0]["id"]
                    created += 1

            # Insert stock batch
            sb.table("stock_batches").insert({
                "product_id": product_id,
                "quantity": qty,
                "unit_price": unit_price,
                "batch_ref": f"{source_vendor.upper()}-{mouser_part or mfg_part or 'IMPORT'}",
                "source": source_invoice,
                "tariff": tariff,
                "added_by": current_user.get("sub"),
            }).execute()

            # Atomic stock increment via RPC to avoid race condition
            try:
                sb.rpc("increment_stock", {
                    "p_product_id": product_id,
                    "p_qty": qty
                }).execute()
            except Exception:
                # Fallback: manual upsert if RPC not available
                existing = sb.table("stock_summary").select("*").eq("product_id", product_id).execute()
                if existing.data:
                    current_qty = existing.data[0].get("quantity", 0) or 0
                    sb.table("stock_summary").update({
                        "quantity": current_qty + qty,
                        "last_updated": "now()"
                    }).eq("product_id", product_id).execute()
                else:
                    sb.table("stock_summary").insert({
                        "product_id": product_id,
                        "quantity": qty,
                        "low_stock_threshold": 10,
                    }).execute()

            added += 1

        except Exception as e:
            errors.append(str(e))
            skipped += 1

    # Save invoice record for spend tracking
    if added > 0:
        try:
            # Determine distributor from items
            vendors = list(set(i.get("source_vendor") or "Unknown" for i in items))
            distributor = vendors[0] if len(vendors) == 1 else ", ".join(vendors)
            sb.table("invoices").insert({
                "source_filename": source_invoice,
                "distributor": distributor,
                "total_amount": round(total_spend, 2),
                "total_items": added,
                "imported_by": current_user.get("sub"),
            }).execute()
        except Exception:
            pass  # invoices table optional

    msg = f"{added} item(s) added to stock"
    if created:
        msg += f" ({created} new product(s) auto-created)"
    if skipped:
        msg += f", {skipped} skipped"

    return {
        "success": True,
        "message": msg,
        "added": added,
        "created": created,
        "skipped": skipped,
        "errors": errors[:5] if errors else []
    }


def _make_code(part: str) -> str:
    clean = re.sub(r"[^A-Z0-9\-]", "", part.upper())[:30]
    return clean if clean else "PART-IMPORT"


def _make_name(description: str, mfg_part: str, mouser_part: str) -> str:
    if description and len(description.strip()) > 5:
        return re.sub(r"\s+", " ", description.strip())[:80]
    if mfg_part:
        return f"Part {mfg_part}"
    if mouser_part:
        return f"Mouser {mouser_part}"
    return "Unknown Part"


async def _match_products(items: List[Dict], user: dict) -> List[Dict]:
    sb = get_supabase()
    try:
        all_products = sb.table("products").select("id, name, code, barcode").execute()
        products = all_products.data or []
    except Exception:
        products = []

    for item in items:
        mfg_part = (item.get("mfg_part_number") or "").upper()
        mouser_part = (item.get("mouser_part_number") or "").upper()
        matched = False

        for p in products:
            barcode = (p.get("barcode") or "").upper()
            code = (p.get("code") or "").upper()
            if barcode and (barcode == mfg_part or barcode == mouser_part):
                item["product_id"] = p["id"]
                item["product_name"] = p["name"]
                item["matched"] = True
                matched = True
                break
            if code and (code == mfg_part or code == mouser_part):
                item["product_id"] = p["id"]
                item["product_name"] = p["name"]
                item["matched"] = True
                matched = True
                break

        if not matched:
            item["matched"] = False
            item["product_id"] = None
            item["product_name"] = None

    return items
