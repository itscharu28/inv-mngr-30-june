from fastapi import APIRouter, Depends, HTTPException
from auth.jwt_handler import get_current_user
from db.supabase_client import get_supabase, reset_client

router = APIRouter(prefix="/stock", tags=["Stock"])


@router.get("/list")
def list_stock(search: str = None, current_user: dict = Depends(get_current_user)):
    try:
        sb = get_supabase()
        result = sb.table("stock_summary").select(
            "*, products(id, name, code, barcode, category, unit_price, description)"
        ).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        result = sb.table("stock_summary").select(
            "*, products(id, name, code, barcode, category, unit_price, description)"
        ).execute()

    data = result.data or []

    if search:
        s = search.lower()
        data = [
            d for d in data
            if s in (d.get("products") or {}).get("name", "").lower()
            or s in (d.get("products") or {}).get("code", "").lower()
            or s in (d.get("products") or {}).get("barcode", "").lower()
            or s in (d.get("products") or {}).get("category", "").lower()
        ]

    return {"success": True, "data": data, "total": len(data)}


@router.get("/low")
def low_stock(threshold: int = 10, current_user: dict = Depends(get_current_user)):
    try:
        sb = get_supabase()
        result = sb.table("stock_summary").select(
            "*, products(id, name, code, barcode, category, unit_price)"
        ).lt("quantity", threshold).gt("quantity", 0).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        result = sb.table("stock_summary").select(
            "*, products(id, name, code, barcode, category, unit_price)"
        ).lt("quantity", threshold).gt("quantity", 0).execute()
    data = result.data or []
    return {"success": True, "data": data, "total": len(data)}


@router.get("/out")
def out_of_stock(current_user: dict = Depends(get_current_user)):
    try:
        sb = get_supabase()
        result = sb.table("stock_summary").select(
            "*, products(id, name, code, barcode, category, unit_price)"
        ).eq("quantity", 0).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        result = sb.table("stock_summary").select(
            "*, products(id, name, code, barcode, category, unit_price)"
        ).eq("quantity", 0).execute()
    data = result.data or []
    return {"success": True, "data": data, "total": len(data)}


@router.get("/summary")
def stock_summary(current_user: dict = Depends(get_current_user)):
    try:
        sb = get_supabase()
        result = sb.table("stock_summary").select(
            "quantity, low_stock_threshold, products(name, category, unit_price)"
        ).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        result = sb.table("stock_summary").select(
            "quantity, low_stock_threshold, products(name, category, unit_price)"
        ).execute()

    data = result.data or []

    total_items = len(data)
    total_qty = sum(d.get("quantity", 0) for d in data)
    total_value = sum(
        d.get("quantity", 0) * ((d.get("products") or {}).get("unit_price") or 0)
        for d in data
    )
    low_stock = sum(
        1 for d in data
        if 0 < d.get("quantity", 0) < (d.get("low_stock_threshold") or 10)
    )
    out_of_stock = sum(1 for d in data if d.get("quantity", 0) == 0)

    by_category = {}
    for d in data:
        cat = (d.get("products") or {}).get("category") or "Other"
        by_category[cat] = by_category.get(cat, 0) + d.get("quantity", 0)

    return {
        "success": True,
        "data": {
            "total_items": total_items,
            "total_quantity": total_qty,
            "total_value": round(total_value, 2),
            "low_stock": low_stock,
            "out_of_stock": out_of_stock,
            "by_category": by_category,
        }
    }


@router.get("/spend-report")
def spend_report(current_user: dict = Depends(get_current_user)):
    sb = get_supabase()
    try:
        batches = sb.table("stock_batches").select(
            "quantity, unit_price, source, created_at, products(category)"
        ).execute().data or []
    except Exception:
        reset_client()
        sb = get_supabase()
        batches = sb.table("stock_batches").select(
            "quantity, unit_price, source, created_at, products(category)"
        ).execute().data or []

    by_source = {}
    by_category = {}
    for b in batches:
        spend = (b.get("quantity") or 0) * (b.get("unit_price") or 0)
        src = (b.get("source") or "Unknown").split("-")[0].strip()
        cat = (b.get("products") or {}).get("category") or "Other"
        by_source[src] = round(by_source.get(src, 0) + spend, 2)
        by_category[cat] = round(by_category.get(cat, 0) + spend, 2)

    return {
        "success": True,
        "by_distributor": by_source,
        "by_category": by_category,
        "total": round(sum(by_source.values()), 2)
    }


@router.get("/batches/{product_id}")
def stock_batches(product_id: int, current_user: dict = Depends(get_current_user)):
    try:
        sb = get_supabase()
        result = sb.table("stock_batches").select("*").eq("product_id", product_id).order("created_at", desc=True).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        result = sb.table("stock_batches").select("*").eq("product_id", product_id).order("created_at", desc=True).execute()
    return {"success": True, "data": result.data or []}


@router.put("/threshold/{product_id}")
def update_threshold(product_id: int, payload: dict, current_user: dict = Depends(get_current_user)):
    threshold = payload.get("threshold", 10)
    try:
        sb = get_supabase()
        sb.table("stock_summary").update({"low_stock_threshold": threshold}).eq("product_id", product_id).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        sb.table("stock_summary").update({"low_stock_threshold": threshold}).eq("product_id", product_id).execute()
    return {"success": True, "message": "Threshold updated"}