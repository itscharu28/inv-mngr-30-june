from fastapi import APIRouter, HTTPException, Depends
from passlib.context import CryptContext
from auth.jwt_handler import create_access_token, get_current_user
from db.supabase_client import get_supabase, reset_client

router = APIRouter(prefix="/auth", tags=["Auth"])
pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")


@router.post("/register")
def register(payload: dict):
    name = payload.get("name", "").strip()
    email = payload.get("email", "").strip().lower()
    password = payload.get("password", "")

    if not name or not email or not password:
        raise HTTPException(status_code=400, detail="name, email, and password are required")
    if len(password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters")

    try:
        sb = get_supabase()
        existing = sb.table("users").select("id").eq("email", email).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        existing = sb.table("users").select("id").eq("email", email).execute()

    if existing.data:
        raise HTTPException(status_code=409, detail="Email already registered")

    hashed = pwd_ctx.hash(password)

    try:
        result = sb.table("users").insert({
            "name": name,
            "email": email,
            "password_hash": hashed,
            "role": "USER",
        }).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        result = sb.table("users").insert({
            "name": name,
            "email": email,
            "password_hash": hashed,
            "role": "USER",
        }).execute()

    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to create user")

    user = result.data[0]
    token = create_access_token({"sub": str(user["id"]), "email": user["email"], "role": user["role"], "name": user["name"]})
    return {"token": token, "user": {"id": user["id"], "name": user["name"], "email": user["email"], "role": user["role"]}}


@router.post("/login")
def login(payload: dict):
    email = payload.get("email", "").strip().lower()
    password = payload.get("password", "")

    if not email or not password:
        raise HTTPException(status_code=400, detail="Email and password required")

    try:
        sb = get_supabase()
        result = sb.table("users").select("*").eq("email", email).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        result = sb.table("users").select("*").eq("email", email).execute()

    if not result.data:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    user = result.data[0]
    if not pwd_ctx.verify(password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token({"sub": str(user["id"]), "email": user["email"], "role": user["role"], "name": user["name"]})
    return {"token": token, "user": {"id": user["id"], "name": user["name"], "email": user["email"], "role": user["role"]}}


@router.get("/me")
def me(current_user: dict = Depends(get_current_user)):
    return {"success": True, "user": current_user}