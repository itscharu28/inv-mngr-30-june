"""
BOM Import & Dry Run — SM-IMS
Upload a CSV with: designator, mfg_part_number, qty, description
Returns: per-part stock check + shortage flags + can_build result
"""
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from auth.jwt_handler import get_current_user
from db.supabase_client import get_supabase
import csv, io

router = APIRouter(prefix="/bom", tags=["BOM"])


@router.post("/dry-run")
async def bom_dry_run(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    """
    BOM Dry Run — checks if current stock can fulfil a BOM.
    CSV columns (flexible): designator, mfg_part_number / part_number, qty / quantity, description
    """
    content = await file.read()
    if len(content) > 2 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="CSV too large (max 2MB)")

    try:
        text = content.decode("utf-8-sig")  # handles BOM in Excel CSVs
        reader = csv.DictReader(io.StringIO(text))
        bom_items = list(reader)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not parse CSV: {e}")

    if not bom_items:
        raise HTTPException(status_code=400, detail="CSV is empty or has no data rows")

    # Normalize column names (lowercase, strip spaces)
    normalized = []
    for row in bom_items:
        n = {k.strip().lower().replace(" ", "_"): (v or "").strip() for k, v in row.items()}
        normalized.append(n)

    sb = get_supabase()
    stock = sb.table("stock_summary").select(
        "quantity, products(id, name, code, barcode)"
    ).execute().data or []

    # Build lookup map: barcode/code → {qty, name}
    stock_map = {}
    for s in stock:
        p = s.get("products") or {}
        qty = s.get("quantity") or 0
        if p.get("barcode"):
            stock_map[p["barcode"].upper()] = {"qty": qty, "name": p.get("name", "")}
        if p.get("code"):
            stock_map[p["code"].upper()] = {"qty": qty, "name": p.get("name", "")}

    results = []
    for item in normalized:
        # Flexible column name support
        part = (
            item.get("mfg_part_number") or
            item.get("part_number") or
            item.get("mpn") or
            item.get("part") or ""
        ).upper()

        qty_str = item.get("qty") or item.get("quantity") or "1"
        try:
            needed = max(1, int(float(qty_str)))
        except Exception:
            needed = 1

        stock_entry = stock_map.get(part, {})
        in_stock = stock_entry.get("qty", 0)
        matched_name = stock_entry.get("name", "")

        results.append({
            "designator":   item.get("designator", ""),
            "mfg_part":     part,
            "description":  item.get("description", ""),
            "qty_needed":   needed,
            "qty_in_stock": in_stock,
            "product_name": matched_name,
            "status":       "ok" if in_stock >= needed else ("no_match" if not stock_entry else "shortage"),
            "shortage":     max(0, needed - in_stock),
        })

    ok_count       = sum(1 for r in results if r["status"] == "ok")
    shortage_count = sum(1 for r in results if r["status"] == "shortage")
    no_match_count = sum(1 for r in results if r["status"] == "no_match")
    can_build      = shortage_count == 0 and no_match_count == 0

    return {
        "success":     True,
        "can_build":   can_build,
        "total_parts": len(results),
        "ok":          ok_count,
        "shortages":   shortage_count,
        "no_match":    no_match_count,
        "items":       results,
        "summary":     f"{'✅ Can build!' if can_build else f'❌ Cannot build — {shortage_count} shortage(s), {no_match_count} unmatched part(s)'}"
    }
