from fastapi import APIRouter, Depends, HTTPException
from auth.jwt_handler import get_current_user
from db.supabase_client import get_supabase, reset_client
from services.ai_service import answer_stock_query

router = APIRouter(prefix="/ai", tags=["AI"])


@router.post("/query")
async def nl_query(payload: dict, current_user: dict = Depends(get_current_user)):
    question = payload.get("question", "").strip()
    if not question:
        raise HTTPException(status_code=400, detail="Question is required")

    try:
        sb = get_supabase()
        stock = sb.table("stock_summary").select(
            "quantity, products(id, name, code, category, unit_price)"
        ).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        stock = sb.table("stock_summary").select(
            "quantity, products(id, name, code, category, unit_price)"
        ).execute()

    stock_data = [
        {
            "product_id":   (s.get("products") or {}).get("id"),
            "product_name": (s.get("products") or {}).get("name"),
            "category":     (s.get("products") or {}).get("category"),
            "unit_price":   (s.get("products") or {}).get("unit_price"),
            "quantity":     s.get("quantity"),
        }
        for s in (stock.data or [])
    ]

    answer = answer_stock_query(question, stock_data)
    return {"success": True, "question": question, "answer": answer, "data_points": len(stock_data)}


@router.get("/insights")
def get_insights(current_user: dict = Depends(get_current_user)):
    try:
        sb = get_supabase()
        data = sb.table("stock_summary").select(
            "quantity, products(name, category, unit_price)"
        ).execute().data or []
    except Exception:
        reset_client()
        sb = get_supabase()
        data = sb.table("stock_summary").select(
            "quantity, products(name, category, unit_price)"
        ).execute().data or []

    insights = []
    low = [d for d in data if 0 < (d.get("quantity") or 0) < 10]
    if low:
        names = ", ".join((d.get("products") or {}).get("name", "?") for d in low[:3])
        insights.append({
            "type": "warning",
            "title": f"⚠️ Low Stock — {len(low)} item(s)",
            "message": f"{names}{' and more...' if len(low) > 3 else ''}"
        })

    out = [d for d in data if (d.get("quantity") or 0) == 0]
    if out:
        names = ", ".join((d.get("products") or {}).get("name", "?") for d in out[:3])
        insights.append({
            "type": "danger",
            "title": f"🚫 Out of Stock — {len(out)} item(s)",
            "message": f"{names}{' and more...' if len(out) > 3 else ''}"
        })

    total_value = sum(
        (d.get("quantity") or 0) * ((d.get("products") or {}).get("unit_price") or 0)
        for d in data
    )
    insights.append({
        "type": "info",
        "title": "💰 Total Inventory Value",
        "message": f"Current stock worth ${total_value:,.2f} USD"
    })

    if not insights:
        insights.append({
            "type": "info",
            "title": "📦 No stock yet",
            "message": "Scan a Mouser PDF to add parts to inventory"
        })

    return {"success": True, "insights": insights}