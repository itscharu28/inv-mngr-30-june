from fastapi import APIRouter, Depends, HTTPException
from auth.jwt_handler import get_current_user
from db.supabase_client import get_supabase, reset_client

router = APIRouter(prefix="/products", tags=["Products"])


@router.get("/list")
def list_products(search: str = None, current_user: dict = Depends(get_current_user)):
    try:
        sb = get_supabase()
        result = sb.table("products").select("*").order("created_at", desc=True).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        result = sb.table("products").select("*").order("created_at", desc=True).execute()

    data = result.data or []

    if search:
        s = search.lower()
        data = [
            p for p in data
            if s in p.get("name", "").lower()
            or s in p.get("code", "").lower()
            or s in (p.get("barcode") or "").lower()
            or s in (p.get("category") or "").lower()
        ]

    return {"success": True, "data": data, "total": len(data)}


@router.post("/create")
def create_product(payload: dict, current_user: dict = Depends(get_current_user)):
    name = (payload.get("name") or "").strip()
    code = (payload.get("code") or "").strip().upper()

    if not name:
        raise HTTPException(status_code=400, detail="Product name is required")
    if not code:
        raise HTTPException(status_code=400, detail="Product code is required")

    try:
        sb = get_supabase()
        existing = sb.table("products").select("id").eq("code", code).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        existing = sb.table("products").select("id").eq("code", code).execute()

    if existing.data:
        raise HTTPException(status_code=409, detail=f"Product with code '{code}' already exists")

    insert_data = {
        "name": name,
        "code": code,
        "barcode": (payload.get("barcode") or "").strip().upper() or None,
        "category": (payload.get("category") or "").strip() or None,
        "unit_price": float(payload.get("unit_price") or 0),
        "description": (payload.get("description") or "").strip() or None,
        "created_by": current_user.get("sub"),
    }

    try:
        result = sb.table("products").insert(insert_data).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        result = sb.table("products").insert(insert_data).execute()

    if not result.data:
        raise HTTPException(status_code=500, detail="Failed to create product")

    return {"success": True, "data": result.data[0]}


@router.put("/update/{product_id}")
def update_product(product_id: int, payload: dict, current_user: dict = Depends(get_current_user)):
    update_data = {}
    for field in ["name", "barcode", "category", "description"]:
        if field in payload:
            update_data[field] = payload[field]
    if "unit_price" in payload:
        update_data["unit_price"] = float(payload["unit_price"] or 0)
    if "code" in payload:
        update_data["code"] = payload["code"].strip().upper()

    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update")

    try:
        sb = get_supabase()
        result = sb.table("products").update(update_data).eq("id", product_id).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        result = sb.table("products").update(update_data).eq("id", product_id).execute()

    return {"success": True, "data": result.data[0] if result.data else {}}


@router.delete("/delete/{product_id}")
def delete_product(product_id: int, current_user: dict = Depends(get_current_user)):
    try:
        sb = get_supabase()
        sb.table("stock_summary").delete().eq("product_id", product_id).execute()
        sb.table("stock_batches").delete().eq("product_id", product_id).execute()
        sb.table("products").delete().eq("id", product_id).execute()
    except Exception:
        reset_client()
        sb = get_supabase()
        sb.table("stock_summary").delete().eq("product_id", product_id).execute()
        sb.table("stock_batches").delete().eq("product_id", product_id).execute()
        sb.table("products").delete().eq("id", product_id).execute()

    return {"success": True, "message": "Product deleted successfully"}
