-- SM-InventoryManagementSystem — Database Schema v2
-- Run this in your Supabase SQL editor

-- 1. Users
CREATE TABLE IF NOT EXISTS users (
  id            BIGSERIAL PRIMARY KEY,
  name          TEXT NOT NULL,
  email         TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'USER' CHECK (role IN ('ADMIN', 'USER')),
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Products
CREATE TABLE IF NOT EXISTS products (
  id          BIGSERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  code        TEXT NOT NULL UNIQUE,
  barcode     TEXT,          -- MFG Part No stored here for matching
  category    TEXT,
  unit_price  NUMERIC(12,4) DEFAULT 0,
  description TEXT,
  created_by  TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
CREATE INDEX IF NOT EXISTS idx_products_code    ON products(code);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);

-- 3. Stock batches (every import creates a row — full history)
CREATE TABLE IF NOT EXISTS stock_batches (
  id          BIGSERIAL PRIMARY KEY,
  product_id  BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity    INT NOT NULL DEFAULT 0,
  unit_price  NUMERIC(12,4) DEFAULT 0,
  batch_ref   TEXT,
  source      TEXT,          -- invoice filename / reference
  tariff      TEXT,          -- HTS code from Mouser invoice
  added_by    TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_batches_product ON stock_batches(product_id);

-- 4. Stock summary (current qty per product — fast lookups)
CREATE TABLE IF NOT EXISTS stock_summary (
  id                 BIGSERIAL PRIMARY KEY,
  product_id         BIGINT NOT NULL UNIQUE REFERENCES products(id) ON DELETE CASCADE,
  quantity           INT NOT NULL DEFAULT 0,
  low_stock_threshold INT DEFAULT 10,
  last_updated       TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_summary_product ON stock_summary(product_id);

-- 5. Invoices (spend tracking — PRD section 5.2)
CREATE TABLE IF NOT EXISTS invoices (
  id              BIGSERIAL PRIMARY KEY,
  invoice_number  TEXT,
  distributor     TEXT DEFAULT 'Mouser Electronics',
  invoice_date    TEXT,
  source_filename TEXT,
  total_amount    NUMERIC(12,2) DEFAULT 0,
  total_items     INT DEFAULT 0,
  imported_by     TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);
