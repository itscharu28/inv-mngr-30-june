import React, { useState } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const navItems = [
  { to: '/',         label: 'Dashboard',   icon: '📊', exact: true },
  { to: '/scanner',  label: 'PDF Scanner', icon: '📄' },
  { to: '/stock',    label: 'Stock',       icon: '📦' },
  { to: '/products', label: 'Products',    icon: '🔧' },
  { to: '/bom',      label: 'BOM Dry Run', icon: '📋' },
  { to: '/ai-query', label: 'AI Query',    icon: '🤖' },
];

function SoundMatterLogo({ collapsed }) {
  if (collapsed) return (
    <div style={{ width: 36, height: 36, background: '#fff', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
      <span style={{ fontFamily: 'Georgia, serif', fontWeight: 700, fontSize: 13, color: '#0f172a' }}>SM</span>
    </div>
  );
  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <span style={{ fontFamily: 'Georgia,"Times New Roman",serif', fontWeight: 400, fontSize: 22, color: '#fff', letterSpacing: '-0.5px' }}>Sound</span>
      <span style={{ fontFamily: 'Georgia,"Times New Roman",serif', fontWeight: 700, fontSize: 22, color: '#fff', letterSpacing: '-0.5px' }}>Matter</span>
    </div>
  );
}

export default function Layout() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(true);

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <aside style={{ width: open ? 220 : 60, background: '#0f172a', display: 'flex', flexDirection: 'column', transition: 'width 0.25s', flexShrink: 0 }}>
        <div style={{ padding: '18px 14px 14px', borderBottom: '1px solid #1e293b' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, overflow: 'hidden' }}>
            <SoundMatterLogo collapsed={!open} />
            {open && <div style={{ color: '#64748b', fontSize: 10, marginTop: 2, letterSpacing: '0.05em', textTransform: 'uppercase' }}>AI Inventory</div>}
          </div>
        </div>

        <nav style={{ flex: 1, padding: '12px 8px', overflowY: 'auto' }}>
          {navItems.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.exact}
              style={({ isActive }) => ({
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 12px', borderRadius: 8, marginBottom: 2,
                textDecoration: 'none', fontSize: 14, fontWeight: 500,
                color: isActive ? '#fff' : '#94a3b8',
                background: isActive ? '#2563eb' : 'transparent',
                transition: 'all 0.15s', overflow: 'hidden', whiteSpace: 'nowrap',
              })}
            >
              <span style={{ fontSize: 18, flexShrink: 0 }}>{item.icon}</span>
              {open && <span>{item.label}</span>}
            </NavLink>
          ))}
        </nav>

        <div style={{ padding: 12, borderTop: '1px solid #1e293b' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: open ? 8 : 0 }}>
            <div style={{ width: 32, height: 32, background: '#7c3aed', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 13, flexShrink: 0 }}>
              {user?.name?.charAt(0)?.toUpperCase() || 'U'}
            </div>
            {open && (
              <div style={{ overflow: 'hidden' }}>
                <div style={{ color: '#fff', fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{user?.name}</div>
                <div style={{ color: '#64748b', fontSize: 11 }}>{user?.role}</div>
              </div>
            )}
          </div>
          {open && (
            <button onClick={logout} style={{ width: '100%', padding: 8, background: 'transparent', border: '1px solid #1e293b', borderRadius: 6, color: '#94a3b8', fontSize: 13, cursor: 'pointer' }}>
              Logout
            </button>
          )}
        </div>
      </aside>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <header style={{ background: '#fff', borderBottom: '1px solid #e2e8f0', padding: '12px 24px', display: 'flex', alignItems: 'center', gap: 16 }}>
          <button onClick={() => setOpen(!open)} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 20, color: '#64748b', padding: 4 }}>☰</button>
          <span style={{ flex: 1 }} />
          <span style={{ background: '#eff6ff', color: '#2563eb', padding: '4px 12px', borderRadius: 6, fontSize: 12, fontWeight: 600 }}>{user?.name}</span>
        </header>
        <main style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
