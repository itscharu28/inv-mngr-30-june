import axios from 'axios';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:8000',
  timeout: 60000,
});

// Attach token to every request
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Global error handler — redirect to login on 401
api.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.clear();
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

export default api;

export const authAPI = {
  login:    data => api.post('/auth/login', data),
  register: data => api.post('/auth/register', data),
  me:       ()   => api.get('/auth/me'),
};

export const pdfAPI = {
  parse: formData => api.post('/pdf/parse', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 120000,  // OCR can take a while
  }),
  addToStock: payload => api.post('/pdf/add-to-stock', payload),
};

export const stockAPI = {
  list:        params  => api.get('/stock/list', { params }),
  low:         ()      => api.get('/stock/low'),
  out:         ()      => api.get('/stock/out'),
  summary:     ()      => api.get('/stock/summary'),
  spendReport: ()      => api.get('/stock/spend-report'),
  batches:     id      => api.get(`/stock/batches/${id}`),
  setThreshold:(id, t) => api.put(`/stock/threshold/${id}`, { threshold: t }),
};

export const productAPI = {
  list:   params => api.get('/products/list', { params }),
  create: data   => api.post('/products/create', data),
  update: (id, data) => api.put(`/products/update/${id}`, data),
  delete: id     => api.delete(`/products/delete/${id}`),
};

export const aiAPI = {
  query:    question => api.post('/ai/query', { question }),
  insights: ()       => api.get('/ai/insights'),
};

export const bomAPI = {
  dryRun: formData => api.post('/bom/dry-run', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }),
};
