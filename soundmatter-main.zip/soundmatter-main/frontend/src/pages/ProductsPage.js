import React, { useEffect, useState } from 'react';
import { productAPI } from '../services/api';
import toast from 'react-hot-toast';

const EMPTY = { name: '', code: '', barcode: '', category: '', unit_price: '', description: '' };

export default function ProductsPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [editId, setEditId] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    productAPI.list().then(r => setProducts(r.data.data || [])).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const openAdd = () => { setForm(EMPTY); setEditId(null); setModal(true); };
  const openEdit = p => {
    setForm({ name: p.name, code: p.code, barcode: p.barcode || '', category: p.category || '', unit_price: p.unit_price || '', description: p.description || '' });
    setEditId(p.id); setModal(true);
  };

  const save = async e => {
    e.preventDefault();
    setSaving(true);
    try {
      const data = { ...form, unit_price: parseFloat(form.unit_price) || 0 };
      if (editId) {
        await productAPI.update(editId, data);
        toast.success('Product updated');
      } else {
        await productAPI.create(data);
        toast.success('Product created');
      }
      setModal(false); load();
    } catch {} finally { setSaving(false); }
  };

  const del = async id => {
    if (!window.confirm('Delete this product?')) return;
    await productAPI.delete(id);
    toast.success('Deleted'); load();
  };

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">🔧 Products</h1>
        <button onClick={openAdd} className="btn-primary">+ Add Product</button>
      </div>

      <div className="table-container">
        {loading ? (
          <div style={{ padding: 40, textAlign: 'center' }}><span className="spinner" style={{ width: 32, height: 32 }} /></div>
        ) : products.length === 0 ? (
          <div style={{ padding: 60, textAlign: 'center', color: '#94a3b8' }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>📦</div>
            No products yet. Add one to start tracking stock.
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Code</th>
                <th>Barcode / MFG Part</th>
                <th>Category</th>
                <th style={{ textAlign: 'right' }}>Unit Price</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map(p => (
                <tr key={p.id}>
                  <td style={{ fontWeight: 600 }}>{p.name}</td>
                  <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{p.code}</td>
                  <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{p.barcode || '—'}</td>
                  <td>{p.category ? <span style={{ background: '#ede9fe', color: '#6d28d9', borderRadius: 6, padding: '2px 8px', fontSize: 11 }}>{p.category}</span> : '—'}</td>
                  <td style={{ textAlign: 'right' }}>${(p.unit_price || 0).toFixed(3)}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button onClick={() => openEdit(p)} className="btn-secondary" style={{ padding: '5px 12px', fontSize: 12 }}>Edit</button>
                      <button onClick={() => del(p.id)} className="btn-danger" style={{ padding: '5px 12px', fontSize: 12 }}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Modal */}
      {modal && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50 }}>
          <div className="card" style={{ width: 480, maxHeight: '90vh', overflowY: 'auto' }}>
            <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 20 }}>{editId ? 'Edit Product' : 'Add Product'}</h2>
            <form onSubmit={save}>
              {[
                { label: 'Product Name *', key: 'name', required: true },
                { label: 'Product Code *', key: 'code', required: true, placeholder: 'e.g. RES-10K' },
                { label: 'Barcode / MFG Part No.', key: 'barcode', placeholder: 'e.g. SMM02040C1002FB000' },
                { label: 'Category', key: 'category', placeholder: 'e.g. Resistors' },
                { label: 'Unit Price (USD)', key: 'unit_price', type: 'number', step: '0.001' },
                { label: 'Description', key: 'description' },
              ].map(f => (
                <div key={f.key} className="form-group">
                  <label className="form-label">{f.label}</label>
                  <input
                    className="form-input"
                    type={f.type || 'text'}
                    step={f.step}
                    required={f.required}
                    placeholder={f.placeholder || ''}
                    value={form[f.key]}
                    onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                  />
                </div>
              ))}
              <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
                <button type="button" onClick={() => setModal(false)} className="btn-secondary" style={{ flex: 1 }}>Cancel</button>
                <button type="submit" disabled={saving} className="btn-primary" style={{ flex: 1, justifyContent: 'center' }}>
                  {saving ? 'Saving...' : editId ? 'Update' : 'Create'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
