import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { bomAPI } from '../services/api';
import toast from 'react-hot-toast';

export default function BomPage() {
  const [file, setFile]       = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult]   = useState(null);
  const [filter, setFilter]   = useState('all');

  const onDrop = useCallback(accepted => {
    if (accepted.length) { setFile(accepted[0]); setResult(null); }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'text/csv': ['.csv'], 'application/vnd.ms-excel': ['.csv'] },
    multiple: false,
  });

  const run = async () => {
    if (!file) return;
    setLoading(true);
    const form = new FormData();
    form.append('file', file);
    try {
      const res = await bomAPI.dryRun(form);
      setResult(res.data);
      toast.success(res.data.summary);
    } catch (e) {
      toast.error(e.response?.data?.detail || 'BOM dry run failed');
    } finally {
      setLoading(false);
    }
  };

  const filtered = result?.items?.filter(i =>
    filter === 'all' ? true : i.status === filter
  ) || [];

  const statusStyle = s => ({
    ok:       { bg: '#dcfce7', color: '#166534', label: '✓ OK' },
    shortage: { bg: '#fef2f2', color: '#991b1b', label: '⚠ Shortage' },
    no_match: { bg: '#fef9c3', color: '#854d0e', label: '? No Match' },
  }[s] || { bg: '#f1f5f9', color: '#374151', label: s });

  return (
    <div style={{ maxWidth: 960, margin: '0 auto' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">📋 BOM Dry Run</h1>
          <p style={{ color: '#64748b', fontSize: 14, marginTop: 4 }}>
            Upload a BOM CSV to check if current stock is sufficient to build
          </p>
        </div>
      </div>

      <div className="card" style={{ marginBottom: 20 }}>
        <div
          {...getRootProps()}
          style={{
            border: `2px dashed ${isDragActive ? '#2563eb' : '#cbd5e1'}`,
            borderRadius: 10, padding: 36, textAlign: 'center', cursor: 'pointer',
            background: isDragActive ? '#eff6ff' : '#f8fafc', transition: 'all 0.2s',
          }}
        >
          <input {...getInputProps()} />
          <div style={{ fontSize: 36, marginBottom: 10 }}>📊</div>
          {file
            ? <p style={{ fontWeight: 600 }}>{file.name}</p>
            : <p style={{ color: '#64748b' }}>Drag & drop BOM CSV, or click to browse</p>
          }
          <p style={{ color: '#94a3b8', fontSize: 12, marginTop: 6 }}>
            Required columns: designator, mfg_part_number, qty, description
          </p>
        </div>

        {file && (
          <button
            onClick={run} disabled={loading} className="btn-primary"
            style={{ width: '100%', justifyContent: 'center', marginTop: 14, padding: 12 }}
          >
            {loading
              ? <><span className="spinner" style={{ borderColor: 'rgba(255,255,255,0.3)', borderTopColor: '#fff', width: 14, height: 14, borderWidth: 2 }} /> &nbsp;Checking…</>
              : '🔍 Run Dry-Run Check'}
          </button>
        )}
      </div>

      {result && (
        <>
          {/* Result Summary */}
          <div className="card" style={{
            marginBottom: 20,
            background: result.can_build ? '#f0fdf4' : '#fef2f2',
            border: `2px solid ${result.can_build ? '#bbf7d0' : '#fecaca'}`,
          }}>
            <h2 style={{
              fontSize: 20, fontWeight: 700, marginBottom: 16,
              color: result.can_build ? '#166534' : '#991b1b',
            }}>
              {result.summary}
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
              {[
                { label: 'Total Parts', val: result.total_parts, color: '#2563eb' },
                { label: '✓ OK',        val: result.ok,          color: '#059669' },
                { label: '⚠ Shortages', val: result.shortages,   color: '#dc2626' },
                { label: '? No Match',  val: result.no_match,    color: '#d97706' },
              ].map(s => (
                <div key={s.label} style={{
                  background: '#fff', borderRadius: 8,
                  padding: '12px 16px', border: '1px solid #e2e8f0',
                }}>
                  <div style={{ fontSize: 22, fontWeight: 700, color: s.color }}>{s.val}</div>
                  <div style={{ fontSize: 12, color: '#64748b', marginTop: 2 }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Filters */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
            {['all', 'shortage', 'no_match', 'ok'].map(f => (
              <button key={f} onClick={() => setFilter(f)} style={{
                padding: '7px 14px', borderRadius: 8, border: 'none', cursor: 'pointer',
                background: filter === f ? '#2563eb' : '#f1f5f9',
                color: filter === f ? '#fff' : '#374151',
                fontWeight: 600, fontSize: 13,
              }}>
                {f === 'all' ? 'All' : f === 'shortage' ? '⚠ Shortages' : f === 'no_match' ? '? No Match' : '✓ OK'}
              </button>
            ))}
          </div>

          {/* Items Table */}
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Designator</th>
                  <th>MFG Part No.</th>
                  <th>Description</th>
                  <th>Matched Product</th>
                  <th style={{ textAlign: 'center' }}>Qty Needed</th>
                  <th style={{ textAlign: 'center' }}>In Stock</th>
                  <th style={{ textAlign: 'center' }}>Shortage</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((item, i) => {
                  const st = statusStyle(item.status);
                  return (
                    <tr key={i} style={{ background: item.status === 'shortage' ? '#fff5f5' : undefined }}>
                      <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{item.designator || '—'}</td>
                      <td style={{ fontFamily: 'monospace', fontSize: 12, fontWeight: 600 }}>{item.mfg_part}</td>
                      <td style={{ fontSize: 12 }}>{item.description || '—'}</td>
                      <td style={{ fontSize: 12 }}>{item.product_name || <span style={{ color: '#94a3b8' }}>Not found</span>}</td>
                      <td style={{ textAlign: 'center', fontWeight: 600 }}>{item.qty_needed}</td>
                      <td style={{ textAlign: 'center', color: item.qty_in_stock > 0 ? '#059669' : '#dc2626', fontWeight: 600 }}>
                        {item.qty_in_stock}
                      </td>
                      <td style={{ textAlign: 'center', color: item.shortage > 0 ? '#dc2626' : '#059669', fontWeight: 700 }}>
                        {item.shortage > 0 ? `-${item.shortage}` : '—'}
                      </td>
                      <td>
                        <span style={{ background: st.bg, color: st.color, borderRadius: 6, padding: '2px 8px', fontSize: 11, fontWeight: 600 }}>
                          {st.label}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
