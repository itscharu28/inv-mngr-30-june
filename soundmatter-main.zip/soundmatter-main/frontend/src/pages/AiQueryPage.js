import React, { useState } from 'react';
import { aiAPI } from '../services/api';

const SUGGESTIONS = [
  'How many total items are in stock?',
  'Which items have low stock?',
  'What is the total stock value?',
  'How many items are out of stock?',
  'Show stock by category',
];

export default function AiQueryPage() {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState(null);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);

  const ask = async (q) => {
    const query = q || question;
    if (!query.trim()) return;
    setLoading(true);
    try {
      const res = await aiAPI.query(query);
      const entry = { question: query, answer: res.data.answer, data_points: res.data.data_points };
      setHistory(h => [entry, ...h]);
      setAnswer(entry);
      setQuestion('');
    } catch {} finally { setLoading(false); }
  };

  return (
    <div style={{ maxWidth: 800, margin: '0 auto' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">🤖 AI Stock Query</h1>
          <p style={{ color: '#64748b', fontSize: 14, marginTop: 4 }}>
            Ask anything about your inventory in plain English
          </p>
        </div>
      </div>

      {/* Query Box */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div style={{ display: 'flex', gap: 12 }}>
          <input
            className="form-input"
            placeholder="Ask about your inventory... e.g. How many resistors do we have?"
            value={question}
            onChange={e => setQuestion(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && ask()}
            style={{ flex: 1 }}
          />
          <button onClick={() => ask()} disabled={loading || !question.trim()} className="btn-primary">
            {loading ? <span className="spinner" style={{ width: 16, height: 16, borderWidth: 2, borderColor: 'rgba(255,255,255,0.4)', borderTopColor: '#fff' }} /> : 'Ask →'}
          </button>
        </div>

        {/* Suggestions */}
        <div style={{ marginTop: 14 }}>
          <p style={{ fontSize: 12, color: '#94a3b8', marginBottom: 8 }}>Try these:</p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {SUGGESTIONS.map(s => (
              <button key={s} onClick={() => ask(s)} style={{
                padding: '5px 12px', background: '#f1f5f9', border: '1px solid #e2e8f0',
                borderRadius: 6, fontSize: 12, color: '#374151', cursor: 'pointer',
                transition: 'all 0.15s',
              }}>{s}</button>
            ))}
          </div>
        </div>
      </div>

      {/* Latest Answer */}
      {answer && (
        <div className="card" style={{ marginBottom: 20, background: '#f0fdf4', border: '1px solid #bbf7d0' }}>
          <div style={{ fontSize: 13, color: '#64748b', marginBottom: 8 }}>❓ {answer.question}</div>
          <div style={{ fontSize: 16, fontWeight: 500, color: '#0f172a', lineHeight: 1.6 }}>
            🤖 {answer.answer}
          </div>
          <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 8 }}>
            Based on {answer.data_points} stock entries
          </div>
        </div>
      )}

      {/* History */}
      {history.length > 1 && (
        <div className="card">
          <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 16 }}>Query History</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {history.slice(1).map((h, i) => (
              <div key={i} style={{ padding: 14, background: '#f8fafc', borderRadius: 8, border: '1px solid #e2e8f0' }}>
                <div style={{ fontSize: 12, color: '#64748b' }}>❓ {h.question}</div>
                <div style={{ fontSize: 14, color: '#374151', marginTop: 4 }}>🤖 {h.answer}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {history.length === 0 && !answer && (
        <div style={{ textAlign: 'center', padding: 60, color: '#94a3b8' }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🤖</div>
          <p>Ask any question about your stock in plain English.</p>
          <p style={{ fontSize: 13, marginTop: 8 }}>Connect OpenAI API key for advanced answers, or use free HuggingFace mode.</p>
        </div>
      )}
    </div>
  );
}
