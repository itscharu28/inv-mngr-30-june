import React, { useEffect, useState } from 'react';
import { stockAPI, aiAPI } from '../services/api';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const COLORS = ['#2563eb', '#7c3aed', '#059669', '#d97706', '#dc2626', '#0891b2'];

export default function DashboardPage() {
  const [summary, setSummary]   = useState(null);
  const [insights, setInsights] = useState([]);
  const [spend, setSpend]       = useState(null);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    Promise.all([
      stockAPI.summary().then(r => setSummary(r.data.data)).catch(() => {}),
      aiAPI.insights().then(r => setInsights(r.data.insights || [])).catch(() => {}),
      stockAPI.spendReport().then(r => setSpend(r.data)).catch(() => {}),
    ]).finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 300 }}>
      <span className="spinner" style={{ width: 40, height: 40 }} />
    </div>
  );

  const catData   = summary?.by_category
    ? Object.entries(summary.by_category).map(([name, value]) => ({ name, value }))
    : [];
  const spendData = spend?.by_category
    ? Object.entries(spend.by_category).map(([name, value]) => ({ name, value }))
    : [];

  const statCards = [
    { label: 'Total Products',  value: summary?.total_items    || 0,                                         icon: '📦', color: '#2563eb' },
    { label: 'Total Qty',       value: summary?.total_quantity || 0,                                         icon: '🔢', color: '#7c3aed' },
    { label: 'Stock Value',     value: `$${(summary?.total_value || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}`, icon: '💰', color: '#059669' },
    { label: 'Total Spend',     value: `$${(spend?.total || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}`,        icon: '🧾', color: '#0891b2' },
    { label: 'Low Stock',       value: summary?.low_stock      || 0,                                         icon: '⚠️', color: '#d97706' },
    { label: 'Out of Stock',    value: summary?.out_of_stock   || 0,                                         icon: '🚫', color: '#dc2626' },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p style={{ color: '#64748b', fontSize: 14, marginTop: 4 }}>AI-powered inventory overview</p>
        </div>
        <a href="/scanner" className="btn-primary">📄 Scan PDF</a>
      </div>

      {/* Stat cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: 16, marginBottom: 24 }}>
        {statCards.map(c => (
          <div key={c.label} className="card" style={{ textAlign: 'center', padding: 20 }}>
            <div style={{ fontSize: 26, marginBottom: 8 }}>{c.icon}</div>
            <div style={{ fontSize: 22, fontWeight: 700, color: c.color }}>{c.value}</div>
            <div style={{ fontSize: 12, color: '#64748b', marginTop: 4 }}>{c.label}</div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 24 }}>
        {/* Stock by Category pie */}
        <div className="card">
          <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 16 }}>📦 Stock by Category</h3>
          {catData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={catData} cx="50%" cy="50%" outerRadius={75} dataKey="value"
                  label={({ name, percent }) => `${name.split('/')[0]} ${(percent * 100).toFixed(0)}%`}>
                  {catData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v) => [v, 'Qty']} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div style={{ height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: 14 }}>
              No stock yet. <a href="/scanner" style={{ color: '#2563eb', marginLeft: 4 }}>Scan a PDF</a>
            </div>
          )}
        </div>

        {/* Spend by Category bar */}
        <div className="card">
          <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 16 }}>💸 Spend by Category</h3>
          {spendData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={spendData} margin={{ top: 0, right: 0, left: 0, bottom: 40 }}>
                <XAxis dataKey="name" tick={{ fontSize: 11 }} angle={-30} textAnchor="end" interval={0} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={v => `$${v}`} />
                <Tooltip formatter={v => [`$${v.toFixed(2)}`, 'Spend']} />
                <Bar dataKey="value" fill="#2563eb" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div style={{ height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: 14 }}>
              No spend data yet
            </div>
          )}
        </div>
      </div>

      {/* AI Insights */}
      <div className="card" style={{ marginBottom: 24 }}>
        <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 16 }}>🤖 AI Insights</h3>
        {insights.length > 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {insights.map((ins, i) => (
              <div key={i} style={{
                padding: 14, borderRadius: 10,
                background: ins.type === 'danger' ? '#fef2f2' : ins.type === 'warning' ? '#fffbeb' : '#eff6ff',
                border: `1px solid ${ins.type === 'danger' ? '#fecaca' : ins.type === 'warning' ? '#fde68a' : '#bfdbfe'}`,
              }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: ins.type === 'danger' ? '#991b1b' : ins.type === 'warning' ? '#92400e' : '#1e40af' }}>
                  {ins.title}
                </div>
                <div style={{ fontSize: 13, marginTop: 4, color: '#4b5563' }}>{ins.message}</div>
              </div>
            ))}
          </div>
        ) : (
          <div style={{ color: '#94a3b8', fontSize: 14 }}>No insights yet. Add stock to get started.</div>
        )}
      </div>

      {/* Quick Actions */}
      <div className="card">
        <h3 style={{ fontSize: 15, fontWeight: 600, marginBottom: 16 }}>Quick Actions</h3>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <a href="/scanner"  className="btn-primary">📄 Scan Mouser PDF</a>
          <a href="/bom"      className="btn-secondary">📋 BOM Dry Run</a>
          <a href="/products" className="btn-secondary">➕ Add Product</a>
          <a href="/stock"    className="btn-secondary">📦 View Stock</a>
          <a href="/ai-query" className="btn-secondary">🤖 Ask AI</a>
        </div>
      </div>
    </div>
  );
}
