import React, { useRef, useState } from 'react';
import { pdfAPI } from '../services/api';
import toast from 'react-hot-toast';

export default function PdfScannerPage() {
  const fileRef = useRef();
  const [files, setFiles] = useState([]);
  const [step, setStep] = useState('upload');
  const [items, setItems] = useState([]);
  const [overrides, setOverrides] = useState({});
  const [parsing, setParsing] = useState(false);
  const [adding, setAdding] = useState(false);
  const [result, setResult] = useState(null);
  const [invoiceSummaries, setInvoiceSummaries] = useState([]);
  const [scanProgress, setScanProgress] = useState({ done: 0, total: 0 });
  // fileStatuses lives in a ref so adding new files doesn't wipe previous scan results
  const fileStatusesRef = useRef({});
  const [fileStatusesTick, setFileStatusesTick] = useState(0); // force re-render

  const getFileStatuses = () => fileStatusesRef.current;

  const setFileStatus = (filename, status) => {
    fileStatusesRef.current = { ...fileStatusesRef.current, [filename]: status };
    setFileStatusesTick(t => t + 1);
  };

  const clearFileStatuses = () => {
    fileStatusesRef.current = {};
    setFileStatusesTick(t => t + 1);
  };

  const handleFiles = e => {
    const selected = Array.from(e.target.files).filter(f => f.type === 'application/pdf');
    if (selected.length === 0) { toast.error('Only PDF files accepted'); return; }
    // Merge: keep existing files + existing scan statuses, only add NEW files
    setFiles(prev => {
      const existingNames = new Set(prev.map(f => f.name));
      const newFiles = selected.filter(f => !existingNames.has(f.name));
      return [...prev, ...newFiles];
    });
    // Do NOT clear fileStatuses — preserve statuses of already-scanned files
    setItems([]);
    setOverrides({});
    setResult(null);
    setStep('upload');
    setInvoiceSummaries([]);
  };

  const handleDrop = dropped => {
    const pdfs = dropped.filter(f => f.type === 'application/pdf');
    if (!pdfs.length) return;
    setFiles(prev => {
      const existingNames = new Set(prev.map(f => f.name));
      return [...prev, ...pdfs.filter(f => !existingNames.has(f.name))];
    });
  };

  const handleParse = async () => {
    if (files.length === 0) { toast.error('Select at least one PDF'); return; }
    setParsing(true);
    setScanProgress({ done: 0, total: files.length });

    const allItems = [];
    const allSummaries = [];
    const seenInvoiceNos = new Set();

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const fd = new FormData();
        fd.append('file', file);
        const res = await pdfAPI.parse(fd);
        const { items: extracted } = res.data;

        if (extracted && extracted.length > 0) {
          const summary = extracted[0]?.invoice_summary;
          const invoiceNo = summary?.invoice_number || null;

          if (invoiceNo && seenInvoiceNos.has(invoiceNo)) {
            setFileStatus(file.name, { status: 'duplicate', invoiceNo });
            toast(`⛔ Invoice #${invoiceNo} already scanned — ${file.name} skipped`, {
              icon: '🔴',
              style: { background: '#fef2f2', color: '#991b1b', border: '1px solid #fca5a5' },
              duration: 5000,
            });
          } else {
            if (invoiceNo) seenInvoiceNos.add(invoiceNo);
            const tagged = extracted.map(item => ({ ...item, _source: file.name }));
            if (summary) allSummaries.push({ file: file.name, ...summary });
            allItems.push(...tagged);
            setFileStatus(file.name, { status: 'ok', invoiceNo });
          }
        } else {
          setFileStatus(file.name, { status: 'empty' });
        }
      } catch {
        setFileStatus(file.name, { status: 'error' });
        toast.error(`Failed to scan: ${file.name}`);
      }
      setScanProgress({ done: i + 1, total: files.length });
    }

    setParsing(false);

    if (allItems.length === 0) {
      toast.error('No items found in any PDF');
      return;
    }

    setItems(allItems);
    setInvoiceSummaries(allSummaries);
    setStep('preview');
    const statuses = getFileStatuses();
    const dupeCount = Object.values(statuses).filter(s => s.status === 'duplicate').length;
    toast.success(`${allItems.length} item(s) extracted${dupeCount > 0 ? ` (${dupeCount} duplicate invoice(s) skipped)` : ''}`);
  };

  const handleAddToStock = async () => {
    const payload = items.map((item, idx) => {
      const ov = overrides[idx] || {};
      return {
        ...item,
        product_id: ov.product_id !== undefined
          ? (ov.product_id === '' ? null : Number(ov.product_id))
          : item.product_id,
        qty_shipped: ov.qty !== undefined ? Number(ov.qty) : item.qty_shipped,
      };
    });
    if (payload.length === 0) { toast.error('No items to add'); return; }
    setAdding(true);
    try {
      const res = await pdfAPI.addToStock({
        items: payload,
        source_invoice: files.map(f => f.name).join(', '),
      });
      setResult(res.data);
      setStep('done');
      toast.success(res.data.message);
    } catch {
      toast.error('Failed to add to stock');
    } finally {
      setAdding(false);
    }
  };

  const reset = () => {
    setFiles([]);
    setItems([]);
    setOverrides({});
    setResult(null);
    setStep('upload');
    setInvoiceSummaries([]);
    setScanProgress({ done: 0, total: 0 });
    clearFileStatuses();
    if (fileRef.current) fileRef.current.value = '';
  };

  const removeFile = idx => {
    const removed = files[idx];
    setFiles(prev => prev.filter((_, i) => i !== idx));
    // Remove its status
    const next = { ...fileStatusesRef.current };
    delete next[removed.name];
    fileStatusesRef.current = next;
    setFileStatusesTick(t => t + 1);
  };

  const setOv = (idx, key, val) =>
    setOverrides(p => ({ ...p, [idx]: { ...(p[idx] || {}), [key]: val } }));

  const fileStatuses = getFileStatuses();
  const matched = items.filter((item, idx) => item.matched || overrides[idx]?.product_id).length;
  const grandTotal = invoiceSummaries.reduce((sum, s) => sum + (s.invoice_total || 0), 0);
  const totalFreight = invoiceSummaries.reduce((sum, s) => sum + (s.freight || 0), 0);
  const totalTax = invoiceSummaries.reduce((sum, s) => sum + (s.tax || 0), 0);
  const totalMerchandise = invoiceSummaries.reduce((sum, s) => sum + (s.merchandise || 0), 0);

  const getFileBadge = (filename) => {
    const s = fileStatuses[filename];
    if (!s) return null;
    if (s.status === 'duplicate') return (
      <span style={{ background: '#ef4444', color: '#fff', borderRadius: 6, padding: '2px 8px', fontSize: 11, fontWeight: 700, marginLeft: 8, whiteSpace: 'nowrap' }}>
        ⛔ Duplicate #{s.invoiceNo} — Skipped
      </span>
    );
    if (s.status === 'ok') return (
      <span style={{ background: '#22c55e', color: '#fff', borderRadius: 6, padding: '2px 8px', fontSize: 11, fontWeight: 600, marginLeft: 8 }}>
        ✓ {s.invoiceNo ? `Invoice #${s.invoiceNo}` : 'Scanned'}
      </span>
    );
    if (s.status === 'error') return (
      <span style={{ background: '#f97316', color: '#fff', borderRadius: 6, padding: '2px 8px', fontSize: 11, fontWeight: 600, marginLeft: 8 }}>
        ⚠ Scan Failed
      </span>
    );
    return null;
  };

  return (
    <div style={{ maxWidth: 1300, margin: '0 auto' }}>
      <div className="page-header">
        <div>
          <h1 className="page-title">📄 PDF Scanner</h1>
          <p style={{ color: '#64748b', fontSize: 14, marginTop: 4 }}>
            Upload multiple invoices — Mouser, DigiKey, JLCPCB supported
          </p>
        </div>
        {step !== 'upload' && <button onClick={reset} className="btn-secondary">↺ New Scan</button>}
      </div>

      {/* STEP 1: Upload */}
      {step === 'upload' && (
        <div className="card">
          <div
            onClick={() => fileRef.current?.click()}
            style={{ border: '2px dashed #cbd5e1', borderRadius: 12, padding: 48, textAlign: 'center', cursor: 'pointer', transition: 'all 0.2s' }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = '#2563eb'; e.currentTarget.style.background = '#eff6ff'; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = '#cbd5e1'; e.currentTarget.style.background = 'transparent'; }}
            onDragOver={e => { e.preventDefault(); e.currentTarget.style.borderColor = '#2563eb'; e.currentTarget.style.background = '#eff6ff'; }}
            onDrop={e => {
              e.preventDefault();
              e.currentTarget.style.borderColor = '#cbd5e1';
              e.currentTarget.style.background = 'transparent';
              handleDrop(Array.from(e.dataTransfer.files));
            }}
          >
            <div style={{ fontSize: 48, marginBottom: 12 }}>📄</div>
            <p style={{ fontSize: 16, fontWeight: 600, color: '#374151' }}>Click to select PDFs or drag & drop</p>
            <p style={{ color: '#94a3b8', fontSize: 13, marginTop: 6 }}>Mouser · DigiKey · JLCPCB · Text or Scanned PDFs</p>
            <input ref={fileRef} type="file" accept="application/pdf" multiple style={{ display: 'none' }} onChange={handleFiles} />
          </div>

          {files.length > 0 && (
            <div style={{ marginTop: 20 }}>
              <p style={{ fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 10 }}>📋 {files.length} PDF(s) selected:</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
                {files.map((f, i) => {
                  const s = fileStatuses[f.name];
                  const isDupe = s?.status === 'duplicate';
                  const isOk = s?.status === 'ok';
                  return (
                    <div key={i} style={{
                      display: 'flex', alignItems: 'center', gap: 10,
                      padding: '10px 14px', borderRadius: 8,
                      border: isDupe ? '2px solid #ef4444' : isOk ? '1px solid #22c55e' : '1px solid #e2e8f0',
                      background: isDupe ? '#fef2f2' : isOk ? '#f0fdf4' : '#f8fafc',
                    }}>
                      <span style={{ fontSize: 20 }}>📄</span>
                      <span style={{ flex: 1, fontSize: 13, color: isDupe ? '#ef4444' : '#374151', fontWeight: isDupe ? 700 : 400 }}>{f.name}</span>
                      {getFileBadge(f.name)}
                      <span style={{ fontSize: 12, color: '#94a3b8', marginLeft: 8 }}>{(f.size / 1024).toFixed(1)} KB</span>
                      <button onClick={() => removeFile(i)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ef4444', fontSize: 16, padding: '0 4px' }}>✕</button>
                    </div>
                  );
                })}
              </div>

              {parsing && (
                <div style={{ marginBottom: 16 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: '#64748b', marginBottom: 6 }}>
                    <span>Scanning PDF {scanProgress.done} of {scanProgress.total}...</span>
                    <span>{Math.round((scanProgress.done / scanProgress.total) * 100)}%</span>
                  </div>
                  <div style={{ height: 8, background: '#e2e8f0', borderRadius: 4 }}>
                    <div style={{ height: '100%', background: '#2563eb', borderRadius: 4, width: `${(scanProgress.done / scanProgress.total) * 100}%`, transition: 'width 0.3s' }} />
                  </div>
                </div>
              )}

              <div style={{ display: 'flex', gap: 12 }}>
                <button onClick={handleParse} disabled={parsing} className="btn-primary">
                  {parsing
                    ? <><span className="spinner" style={{ width: 16, height: 16, borderWidth: 2, borderColor: 'rgba(255,255,255,0.4)', borderTopColor: '#fff' }} /> Scanning {scanProgress.done}/{scanProgress.total}...</>
                    : `🔍 Scan ${files.length} PDF(s)`}
                </button>
                <button onClick={reset} className="btn-secondary">Clear All</button>
              </div>
              <div style={{ marginTop: 16, display: 'flex', gap: 16, fontSize: 12, color: '#64748b' }}>
                <span>🟢 Scanned OK</span>
                <span>🔴 Duplicate Invoice — skipped</span>
                <span>🟠 Scan failed</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* STEP 2: Preview */}
      {step === 'preview' && items.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {invoiceSummaries.length > 0 && (
            <div className="card" style={{ padding: 20 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, color: '#374151', marginBottom: 16 }}>🧾 Invoice Summary — {invoiceSummaries.length} invoice(s)</h3>
              {invoiceSummaries.length > 1 && (
                <div style={{ marginBottom: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {invoiceSummaries.map((s, i) => (
                    <div key={i} style={{ display: 'flex', gap: 16, padding: '8px 12px', background: '#f8fafc', borderRadius: 8, fontSize: 13, alignItems: 'center', flexWrap: 'wrap' }}>
                      <span style={{ fontWeight: 600, color: '#374151', minWidth: 180 }}>📄 {s.file}</span>
                      {s.invoice_number && <span style={{ color: '#64748b' }}>#{s.invoice_number}</span>}
                      <span style={{ color: '#64748b' }}>Merch: <b>${(s.merchandise || 0).toFixed(2)}</b></span>
                      <span style={{ color: '#2563eb' }}>Freight: <b>${(s.freight || 0).toFixed(2)}</b></span>
                      <span style={{ color: '#d97706' }}>TAX: <b>${(s.tax || 0).toFixed(2)}</b></span>
                      {s.invoice_total && <span style={{ color: '#059669', fontWeight: 700 }}>Total: ${s.invoice_total.toFixed(2)}</span>}
                    </div>
                  ))}
                </div>
              )}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12 }}>
                {[
                  { label: 'Total Merchandise', val: totalMerchandise, color: '#374151' },
                  { label: 'Freight / Shipping', val: totalFreight, color: '#2563eb' },
                  { label: 'TAX', val: totalTax, color: '#d97706' },
                  { label: 'Tariff', val: invoiceSummaries.reduce((s, x) => s + (x.tariff || 0), 0), color: '#7c3aed' },
                  { label: 'Grand Total', val: grandTotal, color: '#059669' },
                ].map(s => (
                  <div key={s.label} style={{ background: '#f8fafc', borderRadius: 8, padding: '10px 14px', border: '1px solid #e2e8f0' }}>
                    <div style={{ fontSize: 11, color: '#64748b', marginBottom: 4 }}>{s.label}</div>
                    <div style={{ fontSize: 18, fontWeight: 700, color: s.color }}>${s.val.toFixed(2)}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16 }}>
            {[
              { label: 'PDFs Scanned', val: invoiceSummaries.length, color: '#64748b' },
              { label: 'Items Found', val: items.length, color: '#2563eb' },
              { label: 'Matched', val: matched, color: '#059669' },
              { label: 'Auto-Create', val: items.length - matched, color: '#d97706' },
            ].map(s => (
              <div key={s.label} className="card" style={{ textAlign: 'center', padding: 16 }}>
                <div style={{ fontSize: 28, fontWeight: 700, color: s.color }}>{s.val}</div>
                <div style={{ fontSize: 12, color: '#64748b', marginTop: 4 }}>{s.label}</div>
              </div>
            ))}
          </div>

          {items.filter(i => !i.matched).length > 0 && (
            <div style={{ padding: 12, background: '#f0f9ff', border: '1px solid #bae6fd', borderRadius: 10, fontSize: 13, color: '#0369a1' }}>
              ℹ️ {items.filter(i => !i.matched).length} item(s) not matched — will be <strong>auto-created</strong> as new products.
            </div>
          )}

          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>#</th><th>Source PDF</th><th>Vendor</th><th>Mouser/Part No.</th>
                  <th>MFG Part No.</th><th>Description</th><th>AI Category</th>
                  <th style={{ textAlign: 'center' }}>Ordered</th><th style={{ textAlign: 'center' }}>Shipped</th>
                  <th style={{ textAlign: 'right' }}>Unit Price</th><th style={{ textAlign: 'right' }}>Extended</th>
                  <th>HTS</th><th>Product</th><th style={{ textAlign: 'center' }}>Qty</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item, idx) => {
                  const ov = overrides[idx] || {};
                  const isMatched = item.matched || (ov.product_id && ov.product_id !== '');
                  const displayQty = ov.qty !== undefined ? ov.qty : (item.qty_shipped ?? item.qty_ordered ?? 1);
                  return (
                    <tr key={idx} style={{ background: !isMatched ? '#f0f9ff' : 'transparent' }}>
                      <td style={{ color: '#94a3b8' }}>{idx + 1}</td>
                      <td style={{ fontSize: 11, color: '#64748b', maxWidth: 120 }}>
                        <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={item._source}>{item._source || '—'}</div>
                      </td>
                      <td>
                        {item.source_vendor && (
                          <span style={{
                            background: item.source_vendor === 'DigiKey' ? '#fef3c7' : item.source_vendor === 'JLCPCB' ? '#dcfce7' : '#dbeafe',
                            color: item.source_vendor === 'DigiKey' ? '#92400e' : item.source_vendor === 'JLCPCB' ? '#166534' : '#1d4ed8',
                            borderRadius: 6, padding: '2px 8px', fontSize: 11, fontWeight: 600
                          }}>{item.source_vendor}</span>
                        )}
                      </td>
                      <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{item.mouser_part_number || '—'}</td>
                      <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{item.mfg_part_number || '—'}</td>
                      <td style={{ maxWidth: 160 }}>
                        <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 13 }} title={item.description}>{item.description || '—'}</div>
                      </td>
                      <td>
                        {item.ai_category && (
                          <span style={{ background: '#ede9fe', color: '#6d28d9', borderRadius: 6, padding: '2px 8px', fontSize: 11, fontWeight: 600 }}>{item.ai_category}</span>
                        )}
                      </td>
                      <td style={{ textAlign: 'center' }}>{item.qty_ordered ?? '—'}</td>
                      <td style={{ textAlign: 'center', fontWeight: 600 }}>{item.qty_shipped ?? '—'}</td>
                      <td style={{ textAlign: 'right' }}>{item.unit_price != null ? `$${Number(item.unit_price).toFixed(4)}` : '—'}</td>
                      <td style={{ textAlign: 'right', fontWeight: 600 }}>{item.extended_price != null ? `$${Number(item.extended_price).toFixed(2)}` : '—'}</td>
                      <td style={{ fontFamily: 'monospace', fontSize: 11, color: '#64748b' }}>{item.tariff || '—'}</td>
                      <td>
                        {isMatched && !ov.product_id ? (
                          <span style={{ background: '#dcfce7', color: '#166534', borderRadius: 6, padding: '3px 8px', fontSize: 12, fontWeight: 600 }}>✓ {item.product_name}</span>
                        ) : (
                          <span style={{ background: '#dbeafe', color: '#1d4ed8', borderRadius: 6, padding: '3px 8px', fontSize: 11, fontWeight: 600 }}>✦ Auto-Create</span>
                        )}
                      </td>
                      <td style={{ textAlign: 'center' }}>
                        <input type="number" min="1" value={displayQty} onChange={e => setOv(idx, 'qty', e.target.value)}
                          style={{ width: 65, padding: '4px 6px', border: '1px solid #d1d5db', borderRadius: 6, fontSize: 12, textAlign: 'center' }} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
            <button onClick={reset} className="btn-secondary">Cancel</button>
            <button onClick={handleAddToStock} disabled={adding} className="btn-primary">
              {adding
                ? <><span className="spinner" style={{ width: 16, height: 16, borderWidth: 2, borderColor: 'rgba(255,255,255,0.4)', borderTopColor: '#fff' }} /> Adding...</>
                : `✅ Add ${items.length} Item(s) to Stock`}
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: Done */}
      {step === 'done' && result && (
        <div className="card" style={{ textAlign: 'center', padding: 60 }}>
          <div style={{ fontSize: 64, marginBottom: 16 }}>✅</div>
          <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 8 }}>Stock Updated!</h2>
          <p style={{ color: '#64748b', marginBottom: 32 }}>{invoiceSummaries.length} invoice(s) processed</p>
          <div style={{ display: 'flex', justifyContent: 'center', gap: 48, marginBottom: 36 }}>
            <div>
              <div style={{ fontSize: 40, fontWeight: 700, color: '#059669' }}>{result.added}</div>
              <div style={{ fontSize: 13, color: '#64748b' }}>Items Added</div>
            </div>
            {result.created > 0 && (
              <div>
                <div style={{ fontSize: 40, fontWeight: 700, color: '#2563eb' }}>{result.created}</div>
                <div style={{ fontSize: 13, color: '#64748b' }}>New Products Created</div>
              </div>
            )}
            {result.skipped > 0 && (
              <div>
                <div style={{ fontSize: 40, fontWeight: 700, color: '#d97706' }}>{result.skipped}</div>
                <div style={{ fontSize: 13, color: '#64748b' }}>Skipped</div>
              </div>
            )}
          </div>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
            <button onClick={reset} className="btn-secondary">Scan More PDFs</button>
            <a href="/stock" className="btn-primary">View Stock →</a>
          </div>
        </div>
      )}
    </div>
  );
}
