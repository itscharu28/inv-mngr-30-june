import React, { useEffect, useState, useCallback } from 'react';
import { stockAPI } from '../services/api';
import toast from 'react-hot-toast';

export default function StockPage() {
  const [stock, setStock]     = useState([]);
  const [tab, setTab]         = useState('all');
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState('');
  const [summary, setSummary] = useState(null);

  const fetchStock = useCallback(() => {
    setLoading(true);
    const req = tab === 'all'
      ? stockAPI.list({ search: search || undefined })
      : tab === 'low' ? stockAPI.low() : stockAPI.out();
    req
      .then(r => setStock(r.data.data || []))
      .catch(() => toast.error('Failed to load stock'))
      .finally(() => setLoading(false));
  }, [tab, search]);

  // Correct dependency: run when tab OR search changes
  useEffect(() => {
    fetchStock();
    stockAPI.summary().then(r => setSummary(r.data.data)).catch(() => {});
  }, [tab, search, fetchStock]);

  const tabs = [
    { id: 'all', label: 'All Stock' },
    { id: 'low', label: '⚠ Low Stock' },
    { id: 'out', label: '🚫 Out of Stock' },
  ];

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">📦 Stock Management</h1>
        <a href="/scanner" className="btn-primary">📄 Import from PDF</a>
      </div>

      {summary && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
          {[
            { label: 'Total Products', val: summary.total_items, color: '#2563eb', icon: '📦' },
            { label: 'Total Value',    val: `$${Number(summary.total_value || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}`, color: '#059669', icon: '💰' },
            { label: 'Low Stock',      val: summary.low_stock,    color: '#d97706', icon: '⚠️' },
            { label: 'Out of Stock',   val: summary.out_of_stock, color: '#dc2626', icon: '🚫' },
          ].map(s => (
            <div key={s.label} className="card" style={{ padding: 16 }}>
              <div style={{ fontSize: 11, color: '#64748b', fontWeight: 600, textTransform: 'uppercase', marginBottom: 8 }}>
                {s.icon} {s.label}
              </div>
              <div style={{ fontSize: 24, fontWeight: 700, color: s.color }}>{s.val}</div>
            </div>
          ))}
        </div>
      )}

      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)} style={{
            padding: '8px 16px', borderRadius: 8, border: 'none',
            background: tab === t.id ? '#2563eb' : '#f1f5f9',
            color: tab === t.id ? '#fff' : '#374151',
            fontWeight: 600, fontSize: 13, cursor: 'pointer',
          }}>{t.label}</button>
        ))}
        {tab === 'all' && (
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
            <input
              placeholder="Search products…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && fetchStock()}
              style={{ padding: '8px 14px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14, outline: 'none', width: 220 }}
            />
            <button onClick={fetchStock} className="btn-secondary" style={{ padding: '8px 14px' }}>Search</button>
          </div>
        )}
      </div>

      <div className="table-container">
        {loading ? (
          <div style={{ padding: 40, textAlign: 'center' }}>
            <span className="spinner" style={{ width: 32, height: 32 }} />
          </div>
        ) : stock.length === 0 ? (
          <div style={{ padding: 60, textAlign: 'center', color: '#94a3b8' }}>
            <div style={{ fontSize: 40, marginBottom: 12 }}>📭</div>
            <p>No stock data found.</p>
            <a href="/scanner" style={{ color: '#2563eb', fontSize: 14 }}>Import from PDF</a>
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Product</th>
                <th>Code</th>
                <th>Barcode / MFG Part</th>
                <th>Category</th>
                <th style={{ textAlign: 'center' }}>Quantity</th>
                <th style={{ textAlign: 'right' }}>Unit Price</th>
                <th style={{ textAlign: 'right' }}>Total Value</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {stock.map((item, i) => {
                const prod = item.products || {};
                const qty = item.quantity || 0;
                const price = prod.unit_price || 0;
                const threshold = item.low_stock_threshold || 10;
                const status = qty === 0
                  ? { label: 'Out of Stock', bg: '#fee2e2', color: '#991b1b' }
                  : qty < threshold
                  ? { label: 'Low Stock',    bg: '#fef9c3', color: '#854d0e' }
                  : { label: 'In Stock',     bg: '#dcfce7', color: '#166534' };
                return (
                  <tr key={i}>
                    <td style={{ fontWeight: 600 }}>{prod.name || '—'}</td>
                    <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{prod.code || '—'}</td>
                    <td style={{ fontFamily: 'monospace', fontSize: 12 }}>{prod.barcode || '—'}</td>
                    <td>
                      {prod.category && (
                        <span style={{ background: '#ede9fe', color: '#6d28d9', borderRadius: 6, padding: '2px 8px', fontSize: 11 }}>
                          {prod.category}
                        </span>
                      )}
                    </td>
                    <td style={{ textAlign: 'center', fontWeight: 700, fontSize: 16 }}>{qty}</td>
                    <td style={{ textAlign: 'right' }}>${price.toFixed(4)}</td>
                    <td style={{ textAlign: 'right', fontWeight: 600 }}>${(qty * price).toFixed(2)}</td>
                    <td>
                      <span style={{ background: status.bg, color: status.color, borderRadius: 6, padding: '3px 10px', fontSize: 12, fontWeight: 600 }}>
                        {status.label}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
