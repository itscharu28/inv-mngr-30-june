# SoundMatter — AI Inventory Scanner

AI-powered PDF invoice scanner & inventory management system supporting Mouser Electronics, DigiKey, and JLCPCB invoices.

## Quick Setup

### Backend

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Fill in SUPABASE_URL, SUPABASE_KEY, JWT_SECRET in .env
uvicorn main:app --reload --port 8000
```

**System dependencies for OCR (image PDFs):**

```bash
# Windows
# Download from: https://github.com/UB-Mannheim/tesseract/wiki

# Ubuntu/Debian
sudo apt install tesseract-ocr poppler-utils

# macOS
brew install tesseract poppler
```

### Frontend

```bash
cd frontend
npm install
npm start
```

### Database

Run `database/schema.sql` in your Supabase SQL Editor.

---

## What was fixed in v2

| Problem | Fix |
|---|---|
| pdfplumber not used | pdfplumber is now the **primary** parser for text PDFs |
| Image PDF slow + qty=0 | PyMuPDF + pytesseract OCR at 150 DPI with grayscale threshold for speed and accuracy |
| AI category wrong (Solder → Resistors) | Rule-based classifier runs **first**, zero-shot AI only for ambiguous items |
| Duplicate pages (OKScanner) | Page deduplication by text fingerprint |
| No Tariff field | Tariff/HTS code extracted from PDF and stored in `stock_batches.tariff` |
| JLCPCB dedup broken | Fixed — uses vendor + description as dedup key when no part number |
| DigiKey negative qty_pending | Fixed — `max(0, ordered - shipped)` applied |
| Race condition in stock update | Fixed — atomic RPC with manual fallback |
| Hardcoded distributor "Mouser" | Fixed — actual vendor name saved per invoice |

## PDF Scanner — how it works

```
Upload PDF
    │
    ▼
pdfplumber (text PDF?)
    │ yes → fast extraction (<2s)
    │ no  → PyMuPDF + pytesseract OCR (30-60s for image PDFs)
    │
    ▼
AI category classification (rule-based, instant)
    │
    ▼
Match against Products table
    │
    ▼
Preview → Add to Stock
```

## Tech Stack

- **Backend**: FastAPI + Python 3.11
- **PDF Parsing**: pdfplumber (text PDFs) + PyMuPDF + pytesseract (scanned/image PDFs)
- **AI Classification**: Rule-based classifier (instant, no model download required)
- **NL Query**: Built-in rule-based stock query engine
- **Database**: Supabase (PostgreSQL)
- **Frontend**: React + React Router
- **Auth**: JWT (server-side verified)
